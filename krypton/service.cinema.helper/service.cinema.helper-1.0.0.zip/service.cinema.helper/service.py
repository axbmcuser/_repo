# -*- coding: utf-8 -*-

import xbmc
import xbmcgui
import time

import simplejson

class MyPlayer( xbmc.Player ):
  
  def __init__( self, *args, **kwargs ):
    xbmc.Player.__init__( self )
    self.videoFinishedPercentage = 80
    
    self.startTimer = time.time()
    self.endTimer = time.time()
    
    self.percentageTimer = time.time()
    self.playerPercentage = 0
    
    self.idleCheckIntervalTimer = time.time()
    
    self.VideoPlayerIsMovie = -1
    self.VideoPlayerDbId = -1
    self.VideoPlayerIsMovieInDb = -1
    self.PlayerAudioOnly = -1
    
    self.skinIsACZG = xbmc.getSkinDir() == "skin.aczg"
  
  def onPlayBackEnded( self ):
    self.onPlayBackStopped()
  
  def onPlayBackStopped( self ):
    
    self.endTimer = time.time()
    
    self.skinIsACZG = xbmc.getSkinDir() == "skin.aczg"
    
    if not self.PlayerAudioOnly:
      xbmc.executebuiltin("SetProperty(PlayBackJustEnded,True,home)")
    
    self.VideoPlayerIsMovie = -1
    self.VideoPlayerDbId = -1
    self.PlayerAudioOnly = -1
    
    if self.VideoPlayerIsMovieInDb:
      self.VideoPlayerIsMovieInDb = -1
      
      ExperimentalPostMovieInfoDialog = xbmc.getCondVisibility("Skin.HasSetting(ExperimentalPostMovieInfoDialog)")
      
      if self.skinIsACZG and ExperimentalPostMovieInfoDialog and self.playerPercentage > self.videoFinishedPercentage:
        
        self.playerPercentage = 0
        
        myPlaylist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlistSize = myPlaylist.size()
        playlistPosition = myPlaylist.getposition()
        
        PostMovieDBID = xbmcgui.Window(10000).getProperty('PostMovieDBID')
        
        if PostMovieDBID != "" and playlistSize <= 1 and playlistPosition <= 0:
          
          ExperimentalPostMovieInfoDialogType = int(xbmc.getInfoLabel("Skin.String(ExperimentalPostMovieInfoDialogType)"))
          
          if ExperimentalPostMovieInfoDialogType > 0:
            xbmc.executebuiltin("ActivateWindow(1190)")
            
            if ExperimentalPostMovieInfoDialogType == 1:
              xbmc.sleep(500)
              
              xbmc.executebuiltin("SetFocus(43260)")
              
              xbmc.sleep(500)
            
              xbmc.executebuiltin("Action(Info)")
            
              xbmc.sleep(500)
            
              xbmc.executebuiltin("Dialog.Close(1190,true)")


  def onPlayBackStarted( self ):
    
    xbmc.executebuiltin("SetProperty(PlayBackJustStarted,True,home)")
    
    self.VideoPlayerIsMovie = -1
    self.VideoPlayerDbId = -1
    self.playerPercentage = 0
    
    xbmc.executebuiltin("SetProperty(PostMovieDBID,,home)")
    
    self.startTimer = time.time()
    
    xbmc.sleep(1000)
    
    self.VideoPlayerIsMovie = xbmc.getCondVisibility('VideoPlayer.Content(Movies)')
    self.VideoPlayerDbId = xbmc.getInfoLabel("VideoPlayer.DBID")
    self.VideoPlayerIsMovieInDb = self.VideoPlayerIsMovie == 1 and self.VideoPlayerDbId > 0 and xbmc.getCondVisibility("VideoPlayer.HasInfo")
    self.PlayerAudioOnly = xbmc.getCondVisibility("Player.HasMedia") and xbmc.getCondVisibility("Player.HasAudio") and not xbmc.getCondVisibility("Player.HasVideo")
    
    if self.VideoPlayerIsMovieInDb:
      
      xbmc.executebuiltin('SetProperty(PostMovieDBID,'+str(self.VideoPlayerDbId)+',home)')

#class end


playerMonitor = MyPlayer()

monitor = xbmc.Monitor()

xbmc.executebuiltin("SetProperty(PlayBackJustStarted,,home)")
xbmc.executebuiltin("SetProperty(PlayBackJustEnded,,home)")


while not xbmc.abortRequested:
  if monitor.waitForAbort(1):
    break
  
  
  IsScrolling = xbmc.getCondVisibility("Container.Scrolling")
  if not IsScrolling:
    
    timeNow = time.time()
    
    # --------------------------------------------------------------------------------
    # Clear PlayBackJustStarted / PlayBackJustEnded after X seconds
    # --------------------------------------------------------------------------------
    PlayBackJustStarted = xbmcgui.Window(10000).getProperty('PlayBackJustStarted')
    
    if PlayBackJustStarted == "True":
      tmpTimerDifference = timeNow - playerMonitor.startTimer
      if tmpTimerDifference > float(1.00):
        xbmc.executebuiltin("SetProperty(PlayBackJustStarted,,home)")
    
    PlayBackJustEnded = xbmcgui.Window(10000).getProperty('PlayBackJustEnded')
    
    if PlayBackJustEnded == "True":
      tmpTimerDifference = timeNow - playerMonitor.endTimer
      if tmpTimerDifference > float(1.00):
        xbmc.executebuiltin("SetProperty(PlayBackJustEnded,,home)")
    
    
    PlayerHasMedia = xbmc.getCondVisibility("Player.HasMedia")
    PlayerHasVideo = xbmc.getCondVisibility("Player.HasVideo")
    PlayerHasAudio = xbmc.getCondVisibility("Player.HasAudio")
    
    playingVideo = PlayerHasMedia and PlayerHasVideo
    playingAudio = PlayerHasMedia and PlayerHasAudio and not PlayerHasVideo
    
    # --------------------------------------------------------------------------------
    # Auto Close VideoOSD/MusicOSD when Idle
    # --------------------------------------------------------------------------------
    if (playingVideo or playingAudio):
      tmpTimerDifference = timeNow - playerMonitor.idleCheckIntervalTimer
      
      if tmpTimerDifference > float(2.50):
        
        playerMonitor.skinIsACZG = xbmc.getSkinDir() == "skin.aczg"
        
        if playerMonitor.skinIsACZG:
          
          tmpKodiIdleTime = xbmc.getGlobalIdleTime()
          
          if tmpKodiIdleTime > 6:
            
            if xbmc.getCondVisibility('Window.IsTopMost(VideoOSD)'):
              xbmc.executebuiltin('Dialog.Close(VideoOSD)')
            
            if xbmc.getCondVisibility('Window.IsTopMost(MusicOSD)'):
              xbmc.executebuiltin('Dialog.Close(MusicOSD)')
          
          
          playerMonitor.idleCheckIntervalTimer = time.time()
    
    
    # --------------------------------------------------------------------------------
    # Save Player DB Movie progress %
    # --------------------------------------------------------------------------------
    if playingVideo and playerMonitor.VideoPlayerIsMovieInDb:
      
      tmpTimerDifference = timeNow - playerMonitor.percentageTimer
      
      if tmpTimerDifference > float(5.00):
        
        jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Player.GetProperties","params":{"playerid":1,"properties":["percentage"]},"id":"1"}')
        jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
        jsonQuery = simplejson.loads(jsonQuery)
        
        if jsonQuery.has_key('result') and jsonQuery['result'].has_key('percentage'):
          playerMonitor.playerPercentage = int(jsonQuery['result']['percentage'])
          
        if False and playerMonitor.VideoPlayerIsMovieInDb and playerMonitor.VideoPlayerDbId:
          jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetMovieDetails","params":{"movieid":'+str(playerMonitor.VideoPlayerDbId)+',"ratings":{"2watchlist":{"rating":6,"votes":666}}}}')
          jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
          jsonQuery = simplejson.loads(jsonQuery)
          
        playerMonitor.percentageTimer = time.time()



    # --------------------------------------------------------------------------------
    # CinemaHelper.UserRating
    # --------------------------------------------------------------------------------
    UserRatingPROCESS = bool(xbmcgui.Window(10000).getProperty('CinemaHelper.UserRating.PROCESS'))
    
    if UserRatingPROCESS:
      UserRatingDbId   = int(xbmcgui.Window(10000).getProperty('CinemaHelper.UserRating.DbId'))
      UserRatingDbType = str(xbmcgui.Window(10000).getProperty('CinemaHelper.UserRating.DbType'))
      UserRatingAction = str(xbmcgui.Window(10000).getProperty('CinemaHelper.UserRating.Action'))
      
      UserRatingIsMovie = UserRatingDbType == "movie"
      UserRatingIsEpisode = UserRatingDbType == "episode"
      UserRatingIsTvShow = UserRatingDbType == "tvshow"
      
      if UserRatingAction and UserRatingDbId and (UserRatingIsMovie or UserRatingIsEpisode or UserRatingIsTvShow):
        
        if UserRatingAction == "WatchListAdd":
          if UserRatingIsMovie:
            jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetMovieDetails","params":{"movieid":'+str(UserRatingDbId)+',"userrating":1}}')
            jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
            jsonQuery = simplejson.loads(jsonQuery)
          if UserRatingIsEpisode:
            jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":'+str(UserRatingDbId)+',"userrating":1}}')
            jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
            jsonQuery = simplejson.loads(jsonQuery)
          if UserRatingIsTvShow:
            jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetTvShowDetails","params":{"tvshowid":'+str(UserRatingDbId)+',"userrating":1}}')
            jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
            jsonQuery = simplejson.loads(jsonQuery)
        
        if UserRatingAction == "WatchListRemove":
          if UserRatingIsMovie:
            jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetMovieDetails","params":{"movieid":'+str(UserRatingDbId)+',"userrating":0}}')
            jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
            jsonQuery = simplejson.loads(jsonQuery)
          if UserRatingIsEpisode:
            jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":'+str(UserRatingDbId)+',"userrating":0}}')
            jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
            jsonQuery = simplejson.loads(jsonQuery)
          if UserRatingIsTvShow:
            jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetTvShowDetails","params":{"tvshowid":'+str(UserRatingDbId)+',"userrating":0}}')
            jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
            jsonQuery = simplejson.loads(jsonQuery)
      
      xbmc.executebuiltin("SetProperty(CinemaHelper.UserRating.PROCESS,,home)")
    
    # --------------------------------------------------------------------------------
    # CinemaHelper.WatchedState
    # --------------------------------------------------------------------------------
    
    WatchedStateReloadSkinFlag = bool(xbmcgui.Window(10000).getProperty('CinemaHelper.WatchedState.ReloadSkin'))
    if WatchedStateReloadSkinFlag:
      MovieInformationClosing =  bool(xbmc.getCondVisibility("Window.IsActive(MovieInformation)"))
    
    if WatchedStateReloadSkinFlag and not MovieInformationClosing:
      if bool(xbmc.getCondVisibility("Window.IsVisible(Videos)")):
        xbmc.executebuiltin("ReloadSkin()")
        xbmc.executebuiltin("SetProperty(CinemaHelper.WatchedState.ReloadSkin,,home)")
      else:
        xbmc.executebuiltin("SetProperty(CinemaHelper.WatchedState.ReloadSkin,,home)")
    
    WatchedStatePROCESS = bool(xbmcgui.Window(10000).getProperty('CinemaHelper.WatchedState.PROCESS'))
    
    if(WatchedStatePROCESS):
      WatchedStateDbId   = int(xbmcgui.Window(10000).getProperty('CinemaHelper.WatchedState.DbId'))
      WatchedStateDbType = str(xbmcgui.Window(10000).getProperty('CinemaHelper.WatchedState.DbType'))
      WatchedStateAction = str(xbmcgui.Window(10000).getProperty('CinemaHelper.WatchedState.Action'))
      
      WatchedStateIsMovie = WatchedStateDbType == "movie"
      WatchedStateIsEpisode = WatchedStateDbType == "episode"
      
      if WatchedStateAction and WatchedStateDbId and (WatchedStateIsMovie or WatchedStateIsEpisode):
        
        if WatchedStateAction == "SetWatched":
          if WatchedStateIsMovie:
            jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetMovieDetails","params":{"movieid":'+str(WatchedStateDbId)+',"playcount":1,"lastplayed":""}}')
            jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
            jsonQuery = simplejson.loads(jsonQuery)
          if WatchedStateIsEpisode:
            jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":'+str(WatchedStateDbId)+',"playcount":1,"lastplayed":""}}')
            jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
            jsonQuery = simplejson.loads(jsonQuery)
        
        if WatchedStateAction == "SetNotWatched":
          if WatchedStateIsMovie:
            jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetMovieDetails","params":{"movieid":'+str(WatchedStateDbId)+',"playcount":0,"lastplayed":""}}')
            jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
            jsonQuery = simplejson.loads(jsonQuery)
          if WatchedStateIsEpisode:
            jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":'+str(WatchedStateDbId)+',"playcount":0,"lastplayed":""}}')
            jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
            jsonQuery = simplejson.loads(jsonQuery)
      
      xbmc.executebuiltin("SetProperty(CinemaHelper.WatchedState.PROCESS,,home)")

#end while
