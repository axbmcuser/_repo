# -*- coding: utf-8 -*-

import xbmc
import sys
import urllib
import xbmcgui

try:
    if not xbmc.getCondVisibility("Player.HasMedia") or xbmcgui.Dialog().yesno("Trailer Search","Kodi is playing media at the moment.[CR][CR]Stop playback and open Web Browser?"):
        xbmc.executebuiltin("PlayerControl(Stop)")
        
        url_base = 'https://www.youtube.com/results?search_query='

        param_base = '&sp='
        param_filter_video_under_4min = 'EgQQARgB'

        url_final = url_base + urllib.quote_plus(sys.argv[1] + ' ' + sys.argv[2] + ' Trailer ' + sys.argv[3]) + param_base + param_filter_video_under_4min
        
        webBrowserType = int(xbmc.getInfoLabel("Skin.String(TrailerSearchWebBrowserType)")) if xbmc.getInfoLabel("Skin.String(TrailerSearchWebBrowserType)") else 0
        
        if not webBrowserType:
            import webbrowser
            webbrowser.open(url_final)
        else:
            webBrowserCustomPath = xbmc.getInfoLabel("Skin.String(TrailerSearchWebBrowserCustomPath)")
            if webBrowserCustomPath:
                webBrowserCustomPath = webBrowserCustomPath.replace('\\','\\\\')
                import subprocess
                subprocess.call(webBrowserCustomPath + ' ' + url_final)
except:
    pass
