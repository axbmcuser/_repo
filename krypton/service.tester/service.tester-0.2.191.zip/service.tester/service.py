# -*- coding: utf-8 -*-

import xbmc
import xbmcaddon
import xbmcvfs
from metadatautils import MetadataUtils
import requests
import json

# Script constants
__addon__      = xbmcaddon.Addon()
__addonid__    = __addon__.getAddonInfo('id')
__version__    = __addon__.getAddonInfo('version')
__language__   = __addon__.getLocalizedString
__cwd__        = __addon__.getAddonInfo('path')

def log(txt):
    if isinstance (txt,str):
        txt = txt.decode("utf-8")
    message = u'%s: %s' % (__addonid__, txt)
    xbmc.log(msg=message.encode("utf-8"), level=xbmc.LOGDEBUG)



class Main:

    def __init__( self ):
        log("version %s started" % __version__)
        
        self.previousitem = ""
        self.selecteditem = ""
        self.dbid = ""
        self.imdbnumber = ""
        self.itempath = ""
        
        self.monitor = xbmc.Monitor()
        self.run_service()

    def run_service(self):
        while not self.monitor.abortRequested():
            if self.monitor.waitForAbort(0.2):
                break
            if ((xbmc.getCondVisibility("Window.IsActive(Videos)") and xbmc.getCondVisibility("Window.Is(Videos)")) or (xbmc.getCondVisibility("Window.IsActive(MovieInformation)") and xbmc.getCondVisibility("Window.Is(MovieInformation)"))) and not xbmc.getCondVisibility("Container.Scrolling") and xbmc.getCondVisibility("Container.Content(Movies)") and not xbmc.getInfoLabel("Container.PluginName"):
                self.selecteditem = xbmc.getInfoLabel("ListItem.DBID")
                if (self.selecteditem and self.selecteditem != self.previousitem):
                    self.previousitem = self.selecteditem
                    
                    if (xbmc.getInfoLabel("ListItem.IMDBNumber") and xbmc.getInfoLabel("ListItem.DBID") and xbmc.getInfoLabel("ListItem.DBTYPE") == 'movie' and not xbmc.getCondVisibility("ListItem.IsFolder")):
                        self.dbid = xbmc.getInfoLabel("ListItem.DBID")
                        self.imdbnumber = xbmc.getInfoLabel("ListItem.IMDBNumber")
                        
                        self.itempath = ""
                        try:
                            ListItemPath = xbmc.getInfoLabel("ListItem.Path")
                            if ListItemPath:
                                self.itempath = ListItemPath
                        except:
                            pass
                        
                        self.set_helper_values()
                        
            else:
                my_container_id = xbmc.getInfoLabel("Window(Home).Property(ListItemHelper.WidgetContainerId)")
                my_container_window = xbmc.getInfoLabel("Window(Home).Property(ListItemHelper.WidgetContainerWindowName)")
                
                if (my_container_id and my_container_window and (xbmc.getCondVisibility("Control.HasFocus("+my_container_id+")") and xbmc.getCondVisibility("Window.IsActive("+my_container_window+")") and xbmc.getCondVisibility("Window.Is("+my_container_window+")")) and not xbmc.getCondVisibility("Window.IsActive(Videos)") and not xbmc.getCondVisibility("Window.IsActive(MovieInformation)")) and not xbmc.getCondVisibility("Container("+my_container_id+").Scrolling") and not xbmc.getInfoLabel("Container("+my_container_id+").PluginName"):
                    self.selecteditem = xbmc.getInfoLabel("Container("+my_container_id+").ListItem.DBID")
                    if (self.selecteditem and self.selecteditem != self.previousitem):
                        self.previousitem = self.selecteditem
                        if (xbmc.getInfoLabel("Container("+my_container_id+").ListItem.IMDBNumber") and xbmc.getInfoLabel("Container("+my_container_id+").ListItem.DBID") and xbmc.getInfoLabel("Container("+my_container_id+").ListItem.DBTYPE") == 'movie' and not xbmc.getCondVisibility("Container("+my_container_id+").ListItem.IsFolder")):
                            self.dbid = xbmc.getInfoLabel("Container("+my_container_id+").ListItem.DBID")
                            self.imdbnumber = xbmc.getInfoLabel("Container("+my_container_id+").ListItem.IMDBNumber")
                            
                            self.itempath = ""
                            try:
                                ListItemPath = xbmc.getInfoLabel("Container("+my_container_id+").ListItem.Path")
                                if ListItemPath:
                                    self.itempath = ListItemPath
                            except:
                                pass
                            
                            self.set_helper_values()
                            
            if xbmc.getCondVisibility("Skin.HasSetting(ExperimentalShowNtsFile)") and xbmc.getCondVisibility("Window.IsVisible(1103)") and xbmc.getCondVisibility("Window.IsVisible(MovieInformation)") and not xbmc.getInfoLabel("Window(Home).Property(axbmcuserData.ListItem.internalnotes)") and self.dbid:
                try:
                    if(self.itempath):
                        notes_file = self.itempath+'.rls-rmx.nts'
                        notes_file_present = xbmcvfs.exists(notes_file)
                        if(notes_file_present):
                            f = xbmcvfs.File(notes_file)
                            if(f):
                                b = f.read()
                                xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.internalnotes,"'+str(b)+'",home)')
                            f.close()
                except:
                    xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.internalnotes,"N/A",home)')
                
            if xbmc.getInfoLabel("Skin.String(ExperimentalWebHelperDomainName)") and xbmc.getCondVisibility("Window.IsVisible(MovieInformation)") and not xbmc.getInfoLabel("Window(Home).Property(axbmcuserData.ListItem.rating.rottentomatoes.audience)") and xbmc.getInfoLabel("Window(Home).Property(axbmcuserData.ListItem.rating.rottentomatoes.url)") and self.dbid and self.imdbnumber and self.imdbnumber == xbmc.getInfoLabel("Window(Home).Property(axbmcuserData.ListItem.IMDBNumber)"):
                try:
                    dgb_domain = xbmc.getInfoLabel("Skin.String(ExperimentalWebHelperDomainName)")
                    dgb_url = 'http://'+dgb_domain+'/_kdi_listitem_helper.php?url='
                    dgb_url = dgb_url + str(xbmc.getInfoLabel("Window(Home).Property(axbmcuserData.ListItem.rating.rottentomatoes.url)"))
                    
                    response = requests.get(dgb_url)
                    
                    if response and response.content and response.status_code == 200:
                        json_data = json.loads(response.text)
                        for key, value in json_data.items():
                            if key == "rottenTomatoesAudienceMeter" :
                                xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.rating.rottentomatoes.audience,"'+str(value)+'",home)')
                except:
                    pass
                
    #run_service end



    def set_helper_values(self):
		
    #set_helper_values end



if (__name__ == "__main__"):
    Main()
log('script finished.')
