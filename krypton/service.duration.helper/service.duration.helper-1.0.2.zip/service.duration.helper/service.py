# -*- coding: utf-8 -*-

import xbmc, xbmcaddon, xbmcgui

# Script constants
__addon__      = xbmcaddon.Addon()
__addonid__    = __addon__.getAddonInfo('id')
__version__    = __addon__.getAddonInfo('version')
__language__   = __addon__.getLocalizedString
__cwd__        = __addon__.getAddonInfo('path')

def log(txt):
    if isinstance (txt,str):
        txt = txt.decode("utf-8")
    message = u'%s: %s' % (__addonid__, txt)
    xbmc.log(msg=message.encode("utf-8"), level=xbmc.LOGDEBUG)

def get_hours_and_minutes(minutes_string, zeroFill = False):
    try:
        full_minutes = int(minutes_string)
        minutes = full_minutes % 60
        hours   = full_minutes // 60
        if zeroFill:
            return str(hours) + ':' + str(minutes).zfill(2)
        else:
            return str(hours) + ':' + str(minutes)
    except:
        return ''

def get_hours_only(minutes_string, zeroFill = False):
    try:
        full_minutes = int(minutes_string)
        hours   = full_minutes // 60
        if zeroFill:
            return str(hours).zfill(2)
        else:
            return str(hours)
    except:
        return ''

def get_minutes_only(minutes_string, zeroFill = False):
    try:
        full_minutes = int(minutes_string)
        minutes = full_minutes % 60
        if zeroFill:
            return str(minutes).zfill(2)
        else:
            return str(minutes)
    except:
        return ''

class Main:
    def __init__( self ):
        log("version %s started" % __version__)
        
        self.previousitem = ""
        self.selecteditem = ""
        self.duration = ""
        self.dbid = ""
        
        self.monitor = xbmc.Monitor()
        self.run_service()

    def run_service(self):
        while not self.monitor.abortRequested():
            if self.monitor.waitForAbort(0.75):
                break
            
            IsScrolling = xbmc.getCondVisibility("Container.Scrolling")
            if not IsScrolling:
                IsVideoLibraryView = xbmc.getCondVisibility("Window.IsActive(Videos)") and xbmc.getCondVisibility("Window.Is(Videos)")
                IsMovieInfoDialogView = xbmc.getCondVisibility("Window.IsActive(MovieInformation)") and xbmc.getCondVisibility("Window.Is(MovieInformation)")
                IsAddon = xbmc.getInfoLabel("Container.PluginName")
            
            tmpCheckCondition = not IsScrolling and (IsVideoLibraryView or IsMovieInfoDialogView) and not IsAddon
            
            if tmpCheckCondition:
                self.selecteditem = xbmc.getInfoLabel("ListItem.DBID")
                if (self.selecteditem and self.selecteditem != self.previousitem):
                    self.previousitem = self.selecteditem
                    
                    if (xbmc.getInfoLabel("ListItem.DBID") and xbmc.getInfoLabel("ListItem.DBTYPE") and (xbmc.getInfoLabel("ListItem.DBTYPE") == 'movie' or xbmc.getInfoLabel("ListItem.DBTYPE") == 'episode') and not xbmc.getCondVisibility("ListItem.IsFolder")) and xbmc.getInfoLabel("ListItem.Duration"):
                        try:
                            tmpval = float(int(xbmc.getInfoLabel("ListItem.Duration")))
                            if (tmpval > 0) :
                                self.duration = xbmc.getInfoLabel("ListItem.Duration")
                                self.dbid = xbmc.getInfoLabel("ListItem.DBID")
                                self.set_duration_values()
                        except:
                            pass
            else:
                my_container_id = xbmc.getInfoLabel("Window(Home).Property(DurationHelper.WidgetContainerId)")
                my_container_window = xbmc.getInfoLabel("Window(Home).Property(DurationHelper.WidgetContainerWindowName)")
                
                IsScrollingWidget = xbmc.getCondVisibility("Container("+my_container_id+").Scrolling")
                if not IsScrolling and not IsScrollingWidget:
                    ContainerParentWindowActive = xbmc.getCondVisibility("Window.IsActive("+my_container_window+")") and xbmc.getCondVisibility("Window.Is("+my_container_window+")")
                    ContainerCheckedAndFocus = my_container_id and my_container_window and xbmc.getCondVisibility("Control.HasFocus("+my_container_id+")")
                    IsVideoLibraryOrMovieInfoDialogView = xbmc.getCondVisibility("Window.IsActive(Videos)") or xbmc.getCondVisibility("Window.IsActive(MovieInformation)")
                    IsAddon = xbmc.getInfoLabel("Container("+my_container_id+").PluginName")
                
                tmpCheckCondition = not IsScrolling and not IsScrollingWidget and not IsVideoLibraryOrMovieInfoDialogView and ContainerParentWindowActive and ContainerCheckedAndFocus and not IsAddon
                
                if tmpCheckCondition:
                    self.selecteditem = xbmc.getInfoLabel("Container("+my_container_id+").ListItem.DBID")
                    if (self.selecteditem and self.selecteditem != self.previousitem):
                        self.previousitem = self.selecteditem
                        if (xbmc.getInfoLabel("Container("+my_container_id+").ListItem.DBID") and xbmc.getInfoLabel("Container("+my_container_id+").ListItem.DBTYPE") and (xbmc.getInfoLabel("Container("+my_container_id+").ListItem.DBTYPE") == 'movie' or xbmc.getInfoLabel("Container("+my_container_id+").ListItem.DBTYPE") == 'episode') and not xbmc.getCondVisibility("Container("+my_container_id+").ListItem.IsFolder")) and xbmc.getInfoLabel("Container("+my_container_id+").ListItem.Duration"):
                            try:
                                tmpval = float(int(xbmc.getInfoLabel("Container("+my_container_id+").ListItem.Duration")))
                                if (tmpval > 0) :
                                    self.duration = xbmc.getInfoLabel("Container("+my_container_id+").ListItem.Duration")
                                    self.dbid = xbmc.getInfoLabel("Container("+my_container_id+").ListItem.DBID")
                                    self.set_duration_values()
                            except:
                                pass

    #run_service end



    def set_duration_values(self):
        xbmc.executebuiltin('ClearProperty(DurationHelper.DBID,home)')
        xbmc.executebuiltin('ClearProperty(DurationHelper.Duration.H:MM,home)')
        xbmc.executebuiltin('ClearProperty(DurationHelper.Duration.H,home)')
        xbmc.executebuiltin('ClearProperty(DurationHelper.Duration.HH,home)')
        xbmc.executebuiltin('ClearProperty(DurationHelper.Duration.M,home)')
        xbmc.executebuiltin('ClearProperty(DurationHelper.Duration.MM,home)')
        xbmc.executebuiltin('ClearProperty(DurationHelper.InputDurationMinutes,home)')
        # Duration.H:MM
        hours_and_minutes = get_hours_and_minutes(self.duration, True)
        xbmc.executebuiltin('SetProperty(DurationHelper.Duration.H:MM,"'+hours_and_minutes+'",home)')
        # Duration.H
        hours_only = get_hours_only(self.duration, False)
        xbmc.executebuiltin('SetProperty(DurationHelper.Duration.H,"'+hours_only+'",home)')
         # Duration.HH
        hours_only = get_hours_only(self.duration, True)
        xbmc.executebuiltin('SetProperty(DurationHelper.Duration.HH,"'+hours_only+'",home)')
        # Duration.M
        minutes_only = get_minutes_only(self.duration, False)
        xbmc.executebuiltin('SetProperty(DurationHelper.Duration.M,"'+minutes_only+'",home)')
        # Duration.MM
        minutes_only = get_minutes_only(self.duration, True)
        xbmc.executebuiltin('SetProperty(DurationHelper.Duration.MM,"'+minutes_only+'",home)')
        # InputDurationMinutes
        xbmc.executebuiltin('SetProperty(DurationHelper.InputDurationMinutes,"'+self.duration+'",home)')
        # DBID
        xbmc.executebuiltin('SetProperty(DurationHelper.DBID,"'+self.dbid+'",home)')

if (__name__ == "__main__"):
    Main()
log('script finished.')
