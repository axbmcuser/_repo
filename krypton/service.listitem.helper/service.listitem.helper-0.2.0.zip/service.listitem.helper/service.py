# -*- coding: UTF-8 -*-

import xbmc, xbmcaddon

from metadatautils import MetadataUtils


# Script constants
__addon__      = xbmcaddon.Addon()
__addonid__    = __addon__.getAddonInfo('id')
__version__    = __addon__.getAddonInfo('version')
__language__   = __addon__.getLocalizedString
__cwd__        = __addon__.getAddonInfo('path')

def log(txt):
    if isinstance (txt,str):
        txt = txt.decode("utf-8")
    message = u'%s: %s' % (__addonid__, txt)
    xbmc.log(msg=message.encode("utf-8"), level=xbmc.LOGDEBUG)



class Main:

    def __init__( self ):
        log("version %s started" % __version__)
        self.run_service()

    def run_service(self):
        self.previousitem = ""
        while 1:
            if ((xbmc.getCondVisibility("Window.IsActive(Videos)") and xbmc.getCondVisibility("Window.Is(Videos)")) or (xbmc.getCondVisibility("Window.IsActive(MovieInformation)") and xbmc.getCondVisibility("Window.Is(MovieInformation)"))) and not xbmc.getCondVisibility("Container.Scrolling"):
                self.selecteditem = xbmc.getInfoLabel("ListItem.DBID")
                if (self.selecteditem and self.selecteditem != self.previousitem):
                    self.previousitem = self.selecteditem
                    
                    if (xbmc.getInfoLabel("ListItem.IMDBNumber") and xbmc.getInfoLabel("ListItem.DBID") > -1 and not xbmc.getCondVisibility("ListItem.IsFolder")):
                        self.dbid = xbmc.getInfoLabel("ListItem.DBID")
                        self.imdbnumber = xbmc.getInfoLabel("ListItem.IMDBNumber")
                        
                        self.set_helper_values()
                        
            else:
                my_container_id = xbmc.getInfoLabel("Window(Home).Property(ListItemHelper.WidgetContainerId)")
                my_container_window = xbmc.getInfoLabel("Window(Home).Property(ListItemHelper.WidgetContainerWindowName)")
                
                if (my_container_id and my_container_window and (xbmc.getCondVisibility("Control.HasFocus("+my_container_id+")") and xbmc.getCondVisibility("Window.IsActive("+my_container_window+")") and xbmc.getCondVisibility("Window.Is("+my_container_window+")")) and not xbmc.getCondVisibility("Window.IsActive(Videos)") and not xbmc.getCondVisibility("Window.IsActive(MovieInformation)")) and not xbmc.getCondVisibility("Container("+my_container_id+").Scrolling"):
                    self.selecteditem = xbmc.getInfoLabel("Container("+my_container_id+").ListItem.DBID")
                    if (self.selecteditem and self.selecteditem != self.previousitem):
                        self.previousitem = self.selecteditem
                        
                        if (xbmc.getInfoLabel("Container("+my_container_id+").ListItem.IMDBNumber") and xbmc.getInfoLabel("Container("+my_container_id+").ListItem.DBID") > -1 and not xbmc.getCondVisibility("Container("+my_container_id+").ListItem.IsFolder")):
                            self.dbid = xbmc.getInfoLabel("Container("+my_container_id+").ListItem.DBID")
                            self.imdbnumber = xbmc.getInfoLabel("Container("+my_container_id+").ListItem.IMDBNumber")
                            
                            self.set_helper_values()
            
            
            xbmc.sleep(200)

    def set_helper_values(self):
        log('set_helper_values')
        
        # OMDB
        xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.rating.rottentomatoes.percent,"",home)')
        xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.rating.rottentomatoes.image,"",home)')
        xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.rating.metacritic.percent,"",home)')
        xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.rating.imdb.percent,"",home)')
        xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.rating.imdb,"",home)')
        xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.rating.imdb.votes,"",home)')
        xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.rating.awards,"",home)')
        xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.revenue.boxoffice,"",home)')
        
        # TMDB
        xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.budget,"",home)')
        xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.budget.million,"",home)')
        xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.budget.formatted,"",home)')
        xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.revenue,"",home)')
        xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.revenue.million,"",home)')
        xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.revenue.formatted,"",home)')
        
        # General
        xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.IMDBNumber,"'+str(self.imdbnumber)+'",home)')
        
        mutils = MetadataUtils()
        
        # OMDB
        self.omdb_result = mutils.get_omdb_info(self.imdbnumber)
        
        if (self.omdb_result) :
            #self.tmp_notification = ""
            for key, value in self.omdb_result.items():
                # rotten tomatoes
                if key == "rottentomatoes.rating" :
                    #self.tmp_notification += " rt: " + str(value)
                    xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.rating.rottentomatoes.percent,"'+str(value)+'",home)')
                if key == "rottentomatoes.image" :
                    #self.tmp_notification += " rt img: " + str(value)
                    xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.rating.rottentomatoes.image,"'+str(value)+'",home)')
                # metacritic
                if key == "metacritic.rating" :
                    #self.tmp_notification += " mc: " + str(value)
                    xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.rating.metacritic.percent,"'+str(value)+'",home)')
                # imdb
                if key == "rating.percent.imdb" :
                    #self.tmp_notification += " imdb%: " + str(value)
                    xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.rating.imdb.percent,'+str(value)+',home)')
                if key == "rating.imdb" :
                    #self.tmp_notification += " imdb: " + str(value)
                    xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.rating.imdb,'+str(value)+',home)')
                if key == "votes.imdb" :
                    #self.tmp_notification += " imdb votes: " + str(value)
                    xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.rating.imdb.votes,"'+str(value)+'",home)')
                # awards
                if key == "awards" :
                    #self.tmp_notification += " awards: " + str(value)
                    xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.awards,"'+str(value)+'",home)')
                # boxoffice
                if key == "boxoffice" :
                    #self.tmp_notification += " boxoffice: " + str(value)
                    xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.revenue.boxoffice,"'+str(value)+'",home)')
            
            #xbmc.executebuiltin((u'Notification("%s","%s",%i)' % ('ListItem Helper' , self.tmp_notification, 2500)).encode('utf-8', 'ignore'))
        
        # TMDB
        self.tmdb_result = mutils.get_tmdb_details(self.imdbnumber)
        
        if (self.tmdb_result) :
            #self.tmp_notification = ""
            for key, value in self.tmdb_result.items():
                # budget
                if key == "budget" and value :
                    try:
                        tmpval = float(int(value))
                        if (tmpval > 0) :
                            xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.budget,"'+str(value)+'",home)')
                            try:
                                tmpval = round(float(int(value))/1000000, 2)
                                if tmpval.is_integer() :
                                    tmpval = '%.0f' % tmpval
                                xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.budget.million,"'+str(tmpval)+'",home)')
                            except:
                                pass
                    except:
                        pass
                if key == "budget.formatted" and value :
                    try:
                        if (value != '0') :
                             xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.budget.formatted,"'+str(value)+'",home)')
                    except:
                        pass
                # revenue
                if key == "revenue" and value :
                    try:
                        tmpval = float(int(value))
                        if (tmpval > 0) :
                            xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.revenue,"'+str(value)+'",home)')
                            try:
                                tmpval = round(float(int(value))/1000000, 2)
                                if tmpval.is_integer() :
                                    tmpval = '%.0f' % tmpval
                                xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.revenue.million,"'+str(tmpval)+'",home)')
                            except:
                                pass
                    except:
                        pass
                if key == "revenue.formatted" and value :
                    try:
                        if (value != '0') :
                             xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.revenue.formatted,"'+str(value)+'",home)')
                    except:
                        pass
                # tags
                #if key == "tag" and value :
                #    xbmc.executebuiltin('SetProperty(axbmcuserData.ListItem.tags,"'+str(value)+'",home)')
                #    xbmc.executebuiltin((u'Notification("%s","%s",%i)' % ('ListItem Helper' , value, 2500)).encode('utf-8', 'ignore'))
            
            #xbmc.executebuiltin((u'Notification("%s","%s",%i)' % ('ListItem Helper' , self.tmp_notification, 2500)).encode('utf-8', 'ignore'))
        
        
        #xbmc.executebuiltin((u'Notification(%s,%s,%i)' % ('ListItem Helper' , self.omdb_result, 2000)).encode('utf-8', 'ignore'))
        #log("OMDB RESULTS: %s" % self.omdb_result)
        #log("TMDB RESULTS: %s" % self.tmdb_result)



if (__name__ == "__main__"):
    Main()
log('script finished.')
