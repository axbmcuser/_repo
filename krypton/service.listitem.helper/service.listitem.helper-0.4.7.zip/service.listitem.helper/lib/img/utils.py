#!/usr/bin/python
# coding: utf-8

########################

# Disable image function for TVOS if ImportError
try:
    from lib.img.image import *
    PIL_supported = True
except ImportError:
    PIL_supported = False

########################

import xbmc, xbmcgui, xbmcvfs
def clear_image_cache(params):
    try:
        are_you_sure = xbmcgui.Dialog().yesno("ListItem Helper","Clearing service.listitem.helper image cache. Continue?")
        if are_you_sure :
            some_target = "special://userdata/addon_data/service.listitem.helper/img/"
            target_is_present = xbmcvfs.exists(some_target)
            if target_is_present:
                xbmcvfs.rmdir(some_target,True)
                xbmc.executebuiltin('Notification(service.listitem.helper,image cache cleared,5000,DefaultIconWarning.png)')
            else:
                xbmc.executebuiltin('Notification(service.listitem.helper,image cache already empty,5000,DefaultIconWarning.png)')
    except:
        pass

def blurimg(params):
    if PIL_supported:
        param_file = remove_quotes(params.get('file'))
        if param_file:
            try:
                image_blur(prop=params.get('prop','output'),
                            file=param_file,
                            radius=params.get('radius', None),
                            saturation=params.get('saturation', None),
                            force=params.get('force', None)
                            )
            except:
                pass
