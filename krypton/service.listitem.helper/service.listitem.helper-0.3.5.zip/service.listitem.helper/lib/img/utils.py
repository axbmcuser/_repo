#!/usr/bin/python
# coding: utf-8

########################

# Disable image function for TVOS if ImportError
try:
    from lib.img.image import *
    PIL_supported = True
except ImportError:
    PIL_supported = False

########################

def blurimg(params):
    if PIL_supported:
        image_filter(params.get('prop','output'),remove_quotes(params.get('file')),params.get('radius'))