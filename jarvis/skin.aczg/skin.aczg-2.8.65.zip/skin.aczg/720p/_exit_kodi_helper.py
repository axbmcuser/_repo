import os
os.system("killall -HUP kodi.bin")