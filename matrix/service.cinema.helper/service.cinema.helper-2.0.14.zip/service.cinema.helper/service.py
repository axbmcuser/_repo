# -*- coding: utf-8 -*-

import xbmc
import xbmcaddon
import xbmcgui
import time
import simplejson

__addon__      = xbmcaddon.Addon()
__addonid__    = __addon__.getAddonInfo('id')
__version__    = __addon__.getAddonInfo('version')
__language__   = __addon__.getLocalizedString
__cwd__        = __addon__.getAddonInfo('path')

class MyPlayer( xbmc.Player ):
  
  def __init__( self, *args, **kwargs ):
    xbmc.Player.__init__( self )
    self.videoFinishedPercentage = 80
    
    self.videolibrary_itemseparator = ""
    self.startTimer = time.time()
    self.endTimer = time.time()
    
    self.percentageTimer = time.time()
    self.playerPercentage = 0
    
    self.idleCheckIntervalTimer = time.time()
    
    self.VideoPlayerIsMovie = False
    self.VideoPlayerDbId = -1
    self.VideoPlayerIsMovieInDb = False
    self.PlayerAudioOnly = False
    
    self.movieHasPostCreditsScene = False
    self.nearEndPreReached = False
    self.nearEndReached = ""
    
    self.skinIsACZG = xbmc.getSkinDir() == "skin.aczg"
    
    self.isKodi18plus = False
    self.isKodi19plus = False
    BuildVersionStr = str(xbmc.getInfoLabel('System.BuildVersion')).lower()
    if BuildVersionStr.find("18.") == 0 or BuildVersionStr.find("19.") == 0 or BuildVersionStr.find("20.") == 0 or BuildVersionStr.find("21.") == 0:
      self.isKodi18plus = True
      if BuildVersionStr.find("19.") == 0 or BuildVersionStr.find("20.") == 0 or BuildVersionStr.find("21.") == 0:
        self.isKodi19plus = True
  
  def onPlayBackEnded( self ):
    self.onPlayBackStopped()
  
  def onPlayBackStopped( self ):
    
    xbmc.executebuiltin("ClearProperty(CinemaHelper.player.DBID,home)")
    
    xbmc.executebuiltin("ClearProperty(CinemaHelper.player.nearEndPreReached,home)")
    xbmc.executebuiltin("ClearProperty(CinemaHelper.player.nearEndReached,home)")
    
    xbmc.executebuiltin("ClearProperty(CinemaHelper.player.movieHasPostCreditsScene,home)")
    
    self.movieHasPostCreditsScene = False
    self.nearEndPreReached = False
    self.nearEndReached = ""
    
    self.endTimer = time.time()
    
    self.skinIsACZG = xbmc.getSkinDir() == "skin.aczg"
    
    if not self.PlayerAudioOnly:
      xbmc.executebuiltin("SetProperty(PlayBackJustEnded,True,home)")
    
    self.VideoPlayerIsMovie = False
    self.VideoPlayerDbId = -1
    self.PlayerAudioOnly = False
    
    # studio
    for x in range(1, 51):
      # clear all
      xbmc.executebuiltin('ClearProperty(CinemaHelper.player.studio.'+str(x)+',home)')
    
    if self.VideoPlayerIsMovieInDb:
      self.VideoPlayerIsMovieInDb = False
      
      ExperimentalPostMovieInfoDialogType = int(xbmc.getInfoLabel("Skin.String(ExperimentalPostMovieInfoDialogType)")) if xbmc.getInfoLabel("Skin.String(ExperimentalPostMovieInfoDialogType)") else 0
      
      if self.skinIsACZG and ExperimentalPostMovieInfoDialogType > 0 and self.playerPercentage > self.videoFinishedPercentage:
        
        self.playerPercentage = 0
        
        myPlaylist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlistSize = myPlaylist.size()
        playlistPosition = myPlaylist.getposition()
        
        PostMovieDBID = xbmcgui.Window(10000).getProperty('PostMovieDBID')
        
        if PostMovieDBID != "" and playlistSize <= 1 and playlistPosition <= 0:
          
          if ExperimentalPostMovieInfoDialogType > 0:
            
            xbmc.executebuiltin("SetProperty(ExperimentalPostMovieDialogOpensNow,True,home)")
            
            xbmc.executebuiltin("ActivateWindow(1190)")
            
            if ExperimentalPostMovieInfoDialogType == 1:
              xbmc.sleep(500)
              
              xbmc.executebuiltin("SetFocus(43260)")
              
              xbmc.sleep(500)
            
              xbmc.executebuiltin("Action(Info)")
            
              xbmc.sleep(500)
            
              xbmc.executebuiltin("Dialog.Close(1190,true)")


  def onPlayBackStarted( self ):
    
    xbmc.executebuiltin("SetProperty(PlayBackJustStarted,True,home)")
    
    addon = xbmcaddon.Addon(id="service.listitem.helper")
    self.videolibrary_itemseparator = addon.getSetting("videolibrary_itemseparator") if addon.getSetting("videolibrary_itemseparator") else ' / '
    
    self.VideoPlayerIsMovie = False
    self.VideoPlayerDbId = -1
    self.playerPercentage = 0
    
    xbmc.executebuiltin("ClearProperty(CinemaHelper.player.DBID,home)")
    
    self.startTimer = time.time()
    
    xbmc.executebuiltin("SetProperty(PostMovieDBID,,home)")
    
    xbmc.executebuiltin("ClearProperty(CinemaHelper.player.nearEndPreReached,home)")
    xbmc.executebuiltin("ClearProperty(CinemaHelper.player.nearEndReached,home)")
    
    xbmc.executebuiltin("ClearProperty(CinemaHelper.player.movieHasPostCreditsScene,home)")
    
    self.movieHasPostCreditsScene = False
    self.nearEndPreReached = False
    self.nearEndReached = ""
    
    self.skinIsACZG = xbmc.getSkinDir() == "skin.aczg"
    
    # studio
    for x in range(1, 51):
      # clear all
      xbmc.executebuiltin('ClearProperty(CinemaHelper.player.studio.'+str(x)+',home)')
    xbmc.sleep(1000)
    
    self.VideoPlayerIsMovie = xbmc.getCondVisibility('VideoPlayer.Content(Movies)')
    
    self.VideoPlayerDbId = int(xbmc.getInfoLabel("VideoPlayer.DBID")) if xbmc.getInfoLabel("VideoPlayer.DBID") else -1# int() Python 3 fix
    self.VideoPlayerIsMovieInDb = self.VideoPlayerIsMovie and self.VideoPlayerDbId > 0 and xbmc.getCondVisibility("VideoPlayer.HasInfo")
    self.PlayerAudioOnly = xbmc.getCondVisibility("Player.HasMedia") and xbmc.getCondVisibility("Player.HasAudio") and not xbmc.getCondVisibility("Player.HasVideo")
    
    if self.VideoPlayerDbId > 0:
      xbmc.executebuiltin("SetProperty(CinemaHelper.player.DBID,"+str(self.VideoPlayerDbId)+",home)")
    
    if self.VideoPlayerIsMovieInDb:
      
      tagsQuery = '{"jsonrpc":"2.0","id":"libTags","method":"VideoLibrary.GetMovieDetails","params":{"movieid":'+str(playerMonitor.VideoPlayerDbId)+',"properties":["title","tag"]}}'
      
      jsonQuery = xbmc.executeJSONRPC(tagsQuery)
      
      if not playerMonitor.isKodi19plus:# Python 2
        jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
      
      jsonQuery = simplejson.loads(jsonQuery)
      
      if not playerMonitor.isKodi19plus:# Python 2
        tmpHasKeyCheck = jsonQuery.has_key('result') and jsonQuery['result'].has_key('moviedetails') and jsonQuery['result']['moviedetails'].has_key('tag')
      else:# Python 3
        tmpHasKeyCheck = 'result' in jsonQuery and 'moviedetails' in jsonQuery['result'] and 'tag' in jsonQuery['result']['moviedetails']
      
      if tmpHasKeyCheck:
        if 'aftercreditsstinger' in jsonQuery['result']['moviedetails']['tag'] or 'duringcreditsstinger' in jsonQuery['result']['moviedetails']['tag']:
          self.movieHasPostCreditsScene = True
          xbmc.executebuiltin("SetProperty(CinemaHelper.player.movieHasPostCreditsScene,True,home)")
      
      xbmc.executebuiltin('SetProperty(PostMovieDBID,'+str(self.VideoPlayerDbId)+',home)')
      
      VideoPlayerStudio = str(xbmc.getInfoLabel("VideoPlayer.Studio"))
      if VideoPlayerStudio:
        splitString = VideoPlayerStudio.split(self.videolibrary_itemseparator)
        if splitString:
          indexNo = 1
          for item in splitString:
            xbmc.executebuiltin('SetProperty(CinemaHelper.player.studio.'+str(indexNo)+',"'+str(item)+'",home)')
            indexNo += 1

#/class


playerMonitor = MyPlayer()

monitor = xbmc.Monitor()

xbmc.executebuiltin("SetProperty(PlayBackJustStarted,,home)")
xbmc.executebuiltin("SetProperty(PlayBackJustEnded,,home)")




TimerInterval_2_Enabled = True
TimerInterval_3_Enabled = True

TimerInterval_2_ResetSec = float(0.995)
TimerInterval_3_ResetSec = float(4.00)

TimerInterval_2 = time.time()
TimerInterval_3 = time.time()

nearEndPreReached_Minutes = 30
nearEndReached_Minutes    = 10



lastContainerPath = ""
nearEndReachedTimeOutDurationCount = 0

if not playerMonitor.isKodi19plus:# Python 2
  checkAbortRequested = xbmc.abortRequested
else:# Python 3
  checkAbortRequested = monitor.abortRequested()
while not checkAbortRequested:
  if monitor.waitForAbort(0.20):
    break
  
  timeNow = time.time()
  
  
  
  # INTERVAL DEFAULT
  
  lastContainerPathCompare = xbmc.getInfoLabel("Container.folderpath")
  
  if lastContainerPath != lastContainerPathCompare:
    
    playerMonitor.skinIsACZG = xbmc.getSkinDir() == "skin.aczg"
    
    lastContainerPath = lastContainerPathCompare
    
    # OOB Experience for View Modes
    IsAddon = xbmc.getInfoLabel("Container.PluginName")
    
    if not IsAddon and playerMonitor.skinIsACZG:
      
      ForcePresetViewsMoviesCategory_A = 500
      ForcePresetViewsMoviesCategory_B = 508
      ForcePresetViewsMoviesCategory_C = 508
      
      try:
        ForcePresetViewsMoviesCategories = str(xbmc.getInfoLabel("Skin.String(ForcePresetViewsMoviesCategories)"))
        if ForcePresetViewsMoviesCategories:
          ForcePresetViewsMoviesCategoriesArr = ForcePresetViewsMoviesCategories.split(',',3)
          
          if int(ForcePresetViewsMoviesCategoriesArr[0]) > 0:
            ForcePresetViewsMoviesCategory_A = int(ForcePresetViewsMoviesCategoriesArr[0])
          if int(ForcePresetViewsMoviesCategoriesArr[1]) > 0:
            ForcePresetViewsMoviesCategory_B = int(ForcePresetViewsMoviesCategoriesArr[1])
          if int(ForcePresetViewsMoviesCategoriesArr[2]) > 0:
            ForcePresetViewsMoviesCategory_C = int(ForcePresetViewsMoviesCategoriesArr[2])
      except:
        pass
      
      ForcePresetViewsTvShowsCategory_A = 508
      ForcePresetViewsTvShowsCategory_B = 508
      
      try:
        ForcePresetViewsTvShowsCategories = str(xbmc.getInfoLabel("Skin.String(ForcePresetViewsTvShowsCategories)"))
        if ForcePresetViewsTvShowsCategories:
          ForcePresetViewsTvShowsCategoriesArr = ForcePresetViewsTvShowsCategories.split(',',2)
          
          if int(ForcePresetViewsTvShowsCategoriesArr[0]) > 0:
            ForcePresetViewsTvShowsCategory_A = int(ForcePresetViewsTvShowsCategoriesArr[0])
          if int(ForcePresetViewsTvShowsCategoriesArr[1]) > 0:
            ForcePresetViewsTvShowsCategory_B = int(ForcePresetViewsTvShowsCategoriesArr[1])
          
      except:
        pass
      
      
      
      showParentDirItems = xbmc.getCondVisibility("System.GetBool(filelists.showparentdiritems)")
      
      IsVideoLibraryView = xbmc.getCondVisibility("Window.IsActive(Videos)") and xbmc.getCondVisibility("Window.Is(Videos)")
      
      if IsVideoLibraryView:
        
        ExperimentalForcePresetViews = xbmc.getCondVisibility("Skin.HasSetting(ExperimentalForcePresetViews)")
        
        if ExperimentalForcePresetViews:
          IsVideoDb = xbmc.getCondVisibility("String.StartsWith(Container.folderpath,videodb://)")
          IsFilesContent = xbmc.getCondVisibility("Container.Content(Files)")
          
          # movies
          IsMovieContent = xbmc.getCondVisibility("Container.Content(Movies)")
          IsSetsContent = xbmc.getCondVisibility("Container.Content(Sets)")
          
          #tv shows
          IsTvShowsContent = xbmc.getCondVisibility("Container.Content(TvShows)")
          IsSeasonsContent = xbmc.getCondVisibility("Container.Content(Seasons)")
          IsEpisodesContent = xbmc.getCondVisibility("Container.Content(Episodes)")
          
          #genres
          IsGenresContent = xbmc.getCondVisibility("Container.Content(Genres)")
          
          IsSpecialList = xbmc.getCondVisibility("String.StartsWith(Container.FolderPath,special://skin/playlists/)") and xbmc.getCondVisibility("String.Contains(Container.FolderPath,- Special Lists)")
          
          #folder patch movies
          IsSetsMoviesFolderPath = xbmc.getCondVisibility("String.StartsWith(Container.folderpath,videodb://movies/sets/)")
          IsGenresMoviesFolderPath = xbmc.getCondVisibility("String.StartsWith(Container.folderpath,videodb://movies/genres/)")
          IsRecentlyAddedMoviesFolderPath = xbmc.getCondVisibility("String.StartsWith(Container.folderpath,videodb://recentlyaddedmovies/)")
          IsMyListMoviesFolderPath = xbmc.getCondVisibility("String.StartsWith(Container.FolderPath,special://skin/playlists/Movies - Special Lists/_mylist_movies.xsp)")
          
          #folder patch tv shows
          IsGenresTvShowsFolderPath = xbmc.getCondVisibility("String.StartsWith(Container.folderpath,videodb://tvshows/genres/)")
          IsMyListTvShowsFolderPath = xbmc.getCondVisibility("String.StartsWith(Container.FolderPath,special://skin/playlists/TV Shows - Special Lists/_mylist_tvshows.xsp)")
          IsRecentlyAddedEpisodesFolderPath = xbmc.getCondVisibility("String.StartsWith(Container.folderpath,videodb://recentlyaddedepisodes/)")
          
          switchToView = False
          
          # 901 = "Text"
          #  52 = "Modern" (aka Episodes View)
          # 500 = "Wall 2x7"
          # 908 = "Wall 3x9"
          # 909 = "Wall 4x12"
          # 508 = "Fanart"
          
          # standard video files without db entries
          if IsFilesContent and not IsVideoDb:
            switchToView = 52
          
          # global movies
          if IsMovieContent and not IsSetsMoviesFolderPath and not IsGenresMoviesFolderPath and not IsRecentlyAddedMoviesFolderPath and not IsSpecialList and not IsMyListMoviesFolderPath:
            switchToView = ForcePresetViewsMoviesCategory_A#CAT A   "Wall 2x7"
          
          # movies: "my list"
          if IsMovieContent and IsMyListMoviesFolderPath:
            switchToView = ForcePresetViewsMoviesCategory_C#CAT C   "Fanart"
          
          # movie genres: list movies of selected genre
          if IsMovieContent and IsGenresMoviesFolderPath:
            switchToView = ForcePresetViewsMoviesCategory_A#CAT A   "Wall 2x7"
          
          # movie sets: list sets
          if IsSetsContent:
            switchToView = ForcePresetViewsMoviesCategory_A#CAT A   "Wall 2x7"
          
          # movie sets: list movies of set
          if IsMovieContent and IsSetsMoviesFolderPath:
            switchToView = ForcePresetViewsMoviesCategory_B#CAT B   "Fanart"
          
          # recently added movies
          if IsRecentlyAddedMoviesFolderPath:
            switchToView = ForcePresetViewsMoviesCategory_C#CAT C   "Fanart"
          
          
          # global tv shows
          if IsTvShowsContent and not IsGenresTvShowsFolderPath and not IsSpecialList and not IsMyListTvShowsFolderPath:
            switchToView = ForcePresetViewsTvShowsCategory_A#CAT J   "Fanart"
          
          # global tv show seasons
          if IsSeasonsContent and not IsGenresTvShowsFolderPath:
            switchToView = 901# no customizing, "Text" view is best
          
          # tv shows genres: list shows in selected genre
          if IsTvShowsContent and IsGenresTvShowsFolderPath:
            switchToView = ForcePresetViewsTvShowsCategory_A#CAT J   "Fanart"
          
          # tv show seasons: list seasons in selected genre
          if IsSeasonsContent and IsGenresTvShowsFolderPath:
            switchToView = 901# no customizing, "Text" view is best
          
          # tv shows: list shows in "my list"
          if IsTvShowsContent and IsMyListTvShowsFolderPath:
            switchToView = ForcePresetViewsTvShowsCategory_B#CAT K
          
          
          
          # episodes: viewtype change not necessary due to fixed 52 ("Modern"), but always change to sort by episode no + ascending
          if IsEpisodesContent and IsVideoDb and not IsRecentlyAddedEpisodesFolderPath:
            switchToView = 52
            isSortMethodEpisode = xbmc.getCondVisibility('String.IsEqual(Container.SortMethod,$LOCALIZE[20359])')#20359="Episode"
            finalFirstPageActions = 0
            xbmc.executebuiltin('Action(firstpage)')
            if not isSortMethodEpisode:
              finalFirstPageActions = 1
              xbmc.executebuiltin('Container.SetSortMethod(23)')#23=Episode (conflicting Forum+Wiki Info about this. 23 works for Krypton)
              xbmc.executebuiltin('Action(firstpage)')
              xbmc.sleep(25)#short wait before SortDirection check
            else:
              xbmc.executebuiltin('Action(firstpage)')
            
            if xbmc.getCondVisibility('Container.SortDirection(descending)'):
              finalFirstPageActions = 1
              xbmc.executebuiltin('Container.SetSortDirection()')
              xbmc.executebuiltin('Action(firstpage)')
            else:
              xbmc.executebuiltin('Action(firstpage)')
            
            if finalFirstPageActions:
              xbmc.sleep(25)#short wait before final firstpage actions (making sure first item is always selected when viewing episodes)
              for x in range(finalFirstPageActions):
                xbmc.executebuiltin('Action(firstpage)')
          
          if switchToView:
            viewLabelCompare = ''
            if switchToView == 500:
              viewLabelCompare = 'Wall 2x7'
            if switchToView == 908:
              viewLabelCompare = 'Wall 3x9'
            if switchToView == 909:
              viewLabelCompare = 'Wall 4x12'
            if switchToView == 508:
              viewLabelCompare = xbmc.getLocalizedString(31029)
            if switchToView == 901:
              viewLabelCompare = 'Text'
            if switchToView == 52:
              viewLabelCompare = 'Modern'
            
            
            currentView = xbmc.getInfoLabel("Container.ViewMode")
          
          
          
          if switchToView and currentView != viewLabelCompare:
            xbmc.executebuiltin('Container.SetViewMode('+str(switchToView)+')')
            if switchToView == 508 and showParentDirItems:
              # if we just switched to fanart view (508)
              # wait a bit before proceeding to ParentFolder Item skip
              xbmc.sleep(25)
        
        
        if showParentDirItems:
          # Move-Skip ParentFolderItem for Fanart View (on content load)
          FanartViewHasFocus = xbmc.getCondVisibility("Control.HasFocus(508)")
          if FanartViewHasFocus:
            FanartViewListItemIsParentFolder = xbmc.getCondVisibility("Container(508).ListItem.IsParentFolder")
            if FanartViewListItemIsParentFolder:
              xbmc.executebuiltin("Control.Move(508,1)")
  
  
  
  # INTERVAL 2
  
  if TimerInterval_2_Enabled and (timeNow - TimerInterval_2) > TimerInterval_2_ResetSec:
    TimerInterval_2 = time.time()
    
    IsScrolling = xbmc.getCondVisibility("Container.Scrolling")
    if not IsScrolling:
      
      showParentDirItems = xbmc.getCondVisibility("System.GetBool(filelists.showparentdiritems)")
      
      if showParentDirItems:
        # Move-Skip ParentFolderItem for Fanart View (on Idle)
        FanartViewHasFocus = xbmc.getCondVisibility("Control.HasFocus(508)")
        if FanartViewHasFocus:# and bool(xbmc.getCondVisibility("Window.Is(Videos)"))
          if playerMonitor.skinIsACZG:
            FanartViewListItemIsParentFolder = xbmc.getCondVisibility("Container(508).ListItem.IsParentFolder")
            tmpKodiIdleTime = xbmc.getGlobalIdleTime()
            if FanartViewListItemIsParentFolder and tmpKodiIdleTime > 1:
              xbmc.executebuiltin("Control.Move(508,1)")
      
      
      # --------------------------------------------------------------------------------
      # Clear PlayBackJustStarted / PlayBackJustEnded after X seconds
      # --------------------------------------------------------------------------------
      PlayBackJustStarted = xbmcgui.Window(10000).getProperty('PlayBackJustStarted')
      
      if PlayBackJustStarted == "True":
        tmpTimerDifference = timeNow - playerMonitor.startTimer
        if tmpTimerDifference > float(1.00):
          xbmc.executebuiltin("SetProperty(PlayBackJustStarted,,home)")
      
      PlayBackJustEnded = xbmcgui.Window(10000).getProperty('PlayBackJustEnded')
      
      if PlayBackJustEnded == "True":
        tmpTimerDifference = timeNow - playerMonitor.endTimer
        if tmpTimerDifference > float(1.00):
          xbmc.executebuiltin("SetProperty(PlayBackJustEnded,,home)")
      
      
      
      PlayerHasMedia = xbmc.getCondVisibility("Player.HasMedia")
      PlayerHasVideo = xbmc.getCondVisibility("Player.HasVideo")
      PlayerHasAudio = xbmc.getCondVisibility("Player.HasAudio")
      
      playingVideo = PlayerHasMedia and PlayerHasVideo
      playingAudio = PlayerHasMedia and PlayerHasAudio and not PlayerHasVideo
      
      
      # --------------------------------------------------------------------------------
      # Auto Close VideoOSD/MusicOSD when Idle
      # --------------------------------------------------------------------------------
      if (playingVideo or playingAudio):
        tmpTimerDifference = timeNow - playerMonitor.idleCheckIntervalTimer
        
        if tmpTimerDifference > float(2.50):
          
          if playerMonitor.skinIsACZG:
            
            tmpKodiIdleTime = xbmc.getGlobalIdleTime()
            
            if tmpKodiIdleTime > 6:
              
              # Only auto close if subtitle search dialog and similar dialogs are not open
              
              # Check for OsdSubtitleSettings on Kodi 18+, skip this check on Kodi 17
              OsdSubtitleSettingsIsOpen = xbmc.getCondVisibility('Window.IsVisible(OsdSubtitleSettings)') if playerMonitor.isKodi18plus else False
              
              checkForOpenDialogsPassed = not OsdSubtitleSettingsIsOpen and not xbmc.getCondVisibility('Window.IsVisible(OsdVideoSettings)') and not xbmc.getCondVisibility('Window.IsVisible(OsdAudioSettings)') and not xbmc.getCondVisibility('Window.IsVisible(SubtitleSearch)') and not xbmc.getCondVisibility('Window.IsVisible(VideoBookmarks)')
              
              if checkForOpenDialogsPassed:
                  
                  # Workaround for Kodi 18+ due to "Window.IsTopMost" not working right there (tested on Kodi 18)
                  if playerMonitor.isKodi18plus:
                    if xbmc.getCondVisibility('Window.IsActive(VideoOSD)'):
                      xbmc.executebuiltin('Dialog.Close(VideoOSD)')
                    if xbmc.getCondVisibility('Window.IsActive(MusicOSD)'):
                      xbmc.executebuiltin('Dialog.Close(MusicOSD)')
                  else:
                    # regular autoclose check for up to Kodi 17
                    
                    if xbmc.getCondVisibility('Window.IsTopMost(VideoOSD)'):
                      xbmc.executebuiltin('Dialog.Close(VideoOSD)')
                    if xbmc.getCondVisibility('Window.IsTopMost(MusicOSD)'):
                      xbmc.executebuiltin('Dialog.Close(MusicOSD)')
            
            
            playerMonitor.idleCheckIntervalTimer = time.time()
      
      
      # --------------------------------------------------------------------------------
      # Save Player DB Movie progress %
      # --------------------------------------------------------------------------------
      if playingVideo and playerMonitor.VideoPlayerIsMovieInDb:
        
        tmpTimerDifference = timeNow - playerMonitor.percentageTimer
        
        if tmpTimerDifference > float(5.00):
          
          jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Player.GetProperties","params":{"playerid":1,"properties":["percentage"]},"id":"1"}')
          if not playerMonitor.isKodi19plus:# Python 2
            jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
          jsonQuery = simplejson.loads(jsonQuery)
          
          if not playerMonitor.isKodi19plus:# Python 2
            tmpHasKeyCheck = jsonQuery.has_key('result') and jsonQuery['result'].has_key('percentage')
          else:# Python 3
            tmpHasKeyCheck = 'result' in jsonQuery and 'percentage' in jsonQuery['result']
          if tmpHasKeyCheck:
            playerMonitor.playerPercentage = int(jsonQuery['result']['percentage'])
          
          playerMonitor.percentageTimer = time.time()


      # --------------------------------------------------------------------------------
      # CinemaHelper.UserRating
      # --------------------------------------------------------------------------------
      UserRatingPROCESS = bool(xbmcgui.Window(10000).getProperty('CinemaHelper.UserRating.PROCESS'))
      
      if UserRatingPROCESS:
        UserRatingDbId   = int(xbmcgui.Window(10000).getProperty('CinemaHelper.UserRating.DbId'))
        UserRatingDbType = str(xbmcgui.Window(10000).getProperty('CinemaHelper.UserRating.DbType'))
        UserRatingAction = str(xbmcgui.Window(10000).getProperty('CinemaHelper.UserRating.Action'))
        
        UserRatingIsMovie = UserRatingDbType == "movie"
        UserRatingIsEpisode = UserRatingDbType == "episode"
        UserRatingIsTvShow = UserRatingDbType == "tvshow"
        
        if UserRatingAction and UserRatingDbId and (UserRatingIsMovie or UserRatingIsEpisode or UserRatingIsTvShow):
          
          if UserRatingAction == "WatchListAdd":
            
            if UserRatingIsMovie:
              jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetMovieDetails","params":{"movieid":'+str(UserRatingDbId)+',"userrating":1}}')
              if not playerMonitor.isKodi19plus:# Python 2
                jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
              jsonQuery = simplejson.loads(jsonQuery)
            
            if UserRatingIsEpisode:
              jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":'+str(UserRatingDbId)+',"userrating":1}}')
              if not playerMonitor.isKodi19plus:# Python 2
                jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
              jsonQuery = simplejson.loads(jsonQuery)
            
            if UserRatingIsTvShow:
              jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetTvShowDetails","params":{"tvshowid":'+str(UserRatingDbId)+',"userrating":1}}')
              if not playerMonitor.isKodi19plus:# Python 2
                jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
              jsonQuery = simplejson.loads(jsonQuery)
          
          if UserRatingAction == "WatchListRemove":
            
            if UserRatingIsMovie:
              jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetMovieDetails","params":{"movieid":'+str(UserRatingDbId)+',"userrating":0}}')
              if not playerMonitor.isKodi19plus:# Python 2
                jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
              jsonQuery = simplejson.loads(jsonQuery)
            
            if UserRatingIsEpisode:
              jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":'+str(UserRatingDbId)+',"userrating":0}}')
              if not playerMonitor.isKodi19plus:# Python 2
                jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
              jsonQuery = simplejson.loads(jsonQuery)
            
            if UserRatingIsTvShow:
              jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetTvShowDetails","params":{"tvshowid":'+str(UserRatingDbId)+',"userrating":0}}')
              if not playerMonitor.isKodi19plus:# Python 2
                jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
              jsonQuery = simplejson.loads(jsonQuery)
        
        
        xbmc.executebuiltin("ClearProperty(CinemaHelper.UserRating.PROCESS,home)")
      
      
      # --------------------------------------------------------------------------------
      # CinemaHelper.WatchedState
      # --------------------------------------------------------------------------------
      WatchedStatePROCESS = bool(xbmcgui.Window(10000).getProperty('CinemaHelper.WatchedState.PROCESS'))
      
      if(WatchedStatePROCESS):
        WatchedStateDbId   = int(xbmcgui.Window(10000).getProperty('CinemaHelper.WatchedState.DbId'))
        WatchedStateDbType = str(xbmcgui.Window(10000).getProperty('CinemaHelper.WatchedState.DbType'))
        WatchedStateAction = str(xbmcgui.Window(10000).getProperty('CinemaHelper.WatchedState.Action'))
        
        WatchedStateIsMovie = WatchedStateDbType == "movie"
        WatchedStateIsEpisode = WatchedStateDbType == "episode"
        
        if WatchedStateAction and WatchedStateDbId and (WatchedStateIsMovie or WatchedStateIsEpisode):
          
          if WatchedStateAction == "SetWatched":
            if WatchedStateIsMovie:
              jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetMovieDetails","params":{"movieid":'+str(WatchedStateDbId)+',"playcount":1,"lastplayed":""}}')
              if not playerMonitor.isKodi19plus:# Python 2
                jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
              jsonQuery = simplejson.loads(jsonQuery)
            if WatchedStateIsEpisode:
              jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":'+str(WatchedStateDbId)+',"playcount":1,"lastplayed":""}}')
              if not playerMonitor.isKodi19plus:# Python 2
                jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
              jsonQuery = simplejson.loads(jsonQuery)
          
          if WatchedStateAction == "SetNotWatched":
            if WatchedStateIsMovie:
              jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetMovieDetails","params":{"movieid":'+str(WatchedStateDbId)+',"playcount":0,"lastplayed":""}}')
              if not playerMonitor.isKodi19plus:# Python 2
                jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
              jsonQuery = simplejson.loads(jsonQuery)
            if WatchedStateIsEpisode:
              jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":'+str(WatchedStateDbId)+',"playcount":0,"lastplayed":""}}')
              if not playerMonitor.isKodi19plus:# Python 2
                jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
              jsonQuery = simplejson.loads(jsonQuery)
        
        xbmc.executebuiltin("ClearProperty(CinemaHelper.WatchedState.PROCESS,home)")
  
  
  
  # INTERVAL 3
  
  if TimerInterval_3_Enabled and (timeNow - TimerInterval_3) > TimerInterval_3_ResetSec:
    TimerInterval_3 = time.time()
    
    
    IsScrolling = xbmc.getCondVisibility("Container.Scrolling")
    if not IsScrolling:
      
      if playerMonitor.VideoPlayerIsMovieInDb and playerMonitor.movieHasPostCreditsScene and playerMonitor.isPlayingVideo():
        
        timeremaining = (playerMonitor.getTotalTime() - playerMonitor.getTime()) // 60
        
        if timeremaining < nearEndPreReached_Minutes:
          if not playerMonitor.nearEndPreReached:
            playerMonitor.nearEndPreReached = True
            xbmc.executebuiltin("SetProperty(CinemaHelper.player.nearEndPreReached,True,home)")
        else:
          if playerMonitor.nearEndPreReached:
            playerMonitor.nearEndPreReached = False
            xbmc.executebuiltin("ClearProperty(CinemaHelper.player.nearEndPreReached,home)")
        
        if timeremaining < nearEndReached_Minutes:
          if playerMonitor.nearEndReached == "":
            playerMonitor.nearEndReached = "True"
            xbmc.executebuiltin("SetProperty(CinemaHelper.player.nearEndReached,True,home)")
            nearEndReachedTimeOutDurationCount = 0
        
        if playerMonitor.nearEndReached == "True":
          if not playerMonitor.nearEndReached == "TrueAndTimeOut":
            if nearEndReachedTimeOutDurationCount == 2:
              playerMonitor.nearEndReached = "TrueAndTimeOut"
              xbmc.executebuiltin("SetProperty(CinemaHelper.player.nearEndReached,TrueAndTimeOut,home)")
            else:
              nearEndReachedTimeOutDurationCount += 1
      else:
        pass

#/while


