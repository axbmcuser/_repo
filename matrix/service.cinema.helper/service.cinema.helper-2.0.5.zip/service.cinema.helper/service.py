# -*- coding: utf-8 -*-

import xbmc
import xbmcgui
import time

import simplejson

class MyPlayer( xbmc.Player ):
  
  def __init__( self, *args, **kwargs ):
    xbmc.Player.__init__( self )
    self.videoFinishedPercentage = 80
    
    self.startTimer = time.time()
    self.endTimer = time.time()
    
    self.percentageTimer = time.time()
    self.playerPercentage = 0
    
    self.idleCheckIntervalTimer = time.time()
    
    self.VideoPlayerIsMovie = -1
    self.VideoPlayerDbId = -1
    self.VideoPlayerIsMovieInDb = -1
    self.PlayerAudioOnly = -1
    
    self.skinIsACZG = xbmc.getSkinDir() == "skin.aczg"
    
    self.isKodi18plus = False
    self.isKodi19plus = False
    BuildVersionStr = str(xbmc.getInfoLabel('System.BuildVersion')).lower()
    if BuildVersionStr.find("18.") == 0 or BuildVersionStr.find("19.") == 0 or BuildVersionStr.find("20.") == 0:
      self.isKodi18plus = True
      if BuildVersionStr.find("19.") == 0 or BuildVersionStr.find("20.") == 0:
        self.isKodi19plus = True
  
  def onPlayBackEnded( self ):
    self.onPlayBackStopped()
  
  def onPlayBackStopped( self ):
    
    self.endTimer = time.time()
    
    self.skinIsACZG = xbmc.getSkinDir() == "skin.aczg"
    
    if not self.PlayerAudioOnly:
      xbmc.executebuiltin("SetProperty(PlayBackJustEnded,True,home)")
    
    self.VideoPlayerIsMovie = -1
    self.VideoPlayerDbId = -1
    self.PlayerAudioOnly = -1
    
    if self.VideoPlayerIsMovieInDb:
      self.VideoPlayerIsMovieInDb = -1
      
      ExperimentalPostMovieInfoDialog = int(xbmc.getInfoLabel("Skin.String(ExperimentalPostMovieInfoDialogType)")) > 0
      
      if self.skinIsACZG and ExperimentalPostMovieInfoDialog and self.playerPercentage > self.videoFinishedPercentage:
        
        self.playerPercentage = 0
        
        myPlaylist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlistSize = myPlaylist.size()
        playlistPosition = myPlaylist.getposition()
        
        PostMovieDBID = xbmcgui.Window(10000).getProperty('PostMovieDBID')
        
        if PostMovieDBID != "" and playlistSize <= 1 and playlistPosition <= 0:
          
          ExperimentalPostMovieInfoDialogType = int(xbmc.getInfoLabel("Skin.String(ExperimentalPostMovieInfoDialogType)"))
          
          if ExperimentalPostMovieInfoDialogType > 0:
            xbmc.executebuiltin("ActivateWindow(1190)")
            
            if ExperimentalPostMovieInfoDialogType == 1:
              xbmc.sleep(500)
              
              xbmc.executebuiltin("SetFocus(43260)")
              
              xbmc.sleep(500)
            
              xbmc.executebuiltin("Action(Info)")
            
              xbmc.sleep(500)
            
              xbmc.executebuiltin("Dialog.Close(1190,true)")


  def onPlayBackStarted( self ):
    
    xbmc.executebuiltin("SetProperty(PlayBackJustStarted,True,home)")
    
    self.VideoPlayerIsMovie = -1
    self.VideoPlayerDbId = -1
    self.playerPercentage = 0
    
    xbmc.executebuiltin("SetProperty(PostMovieDBID,,home)")
    
    self.startTimer = time.time()
    
    xbmc.sleep(1000)
    
    self.VideoPlayerIsMovie = xbmc.getCondVisibility('VideoPlayer.Content(Movies)')
    self.VideoPlayerDbId = int(xbmc.getInfoLabel("VideoPlayer.DBID"))# int() Python 3 fix
    self.VideoPlayerIsMovieInDb = self.VideoPlayerIsMovie == 1 and self.VideoPlayerDbId > 0 and xbmc.getCondVisibility("VideoPlayer.HasInfo")
    self.PlayerAudioOnly = xbmc.getCondVisibility("Player.HasMedia") and xbmc.getCondVisibility("Player.HasAudio") and not xbmc.getCondVisibility("Player.HasVideo")
    
    if self.VideoPlayerIsMovieInDb:
      
      xbmc.executebuiltin('SetProperty(PostMovieDBID,'+str(self.VideoPlayerDbId)+',home)')

#/class


playerMonitor = MyPlayer()

monitor = xbmc.Monitor()

xbmc.executebuiltin("SetProperty(PlayBackJustStarted,,home)")
xbmc.executebuiltin("SetProperty(PlayBackJustEnded,,home)")




TimerInterval_1_Enabled = True
TimerInterval_2_Enabled = True

TimerInterval_1_ResetSec = float(0.15)
TimerInterval_2_ResetSec = float(0.995)



TimerInterval_1 = time.time()
TimerInterval_2 = time.time()

lastContainerPath = ""




if not playerMonitor.isKodi19plus:# Python 2
  checkAbortRequested = xbmc.abortRequested
else:# Python 3
  checkAbortRequested = monitor.abortRequested()
while not checkAbortRequested:
  if monitor.waitForAbort(0.1):
    break
  
  timeNow = time.time()
  
  
  # INTERVAL 1
  
  if TimerInterval_1_Enabled and (timeNow - TimerInterval_1) > TimerInterval_1_ResetSec:
    TimerInterval_1 = time.time()
    
    lastContainerPathCompare = xbmc.getInfoLabel("Container.folderpath")
    
    if lastContainerPath != lastContainerPathCompare:
      lastContainerPath = lastContainerPathCompare
      
      
      
      # OOB Experience for View Modes
      IsAddon = xbmc.getInfoLabel("Container.PluginName")
      
      if not IsAddon and playerMonitor.skinIsACZG:
        
        showParentDirItems = xbmc.getCondVisibility("System.GetBool(filelists.showparentdiritems)")
        
        IsVideoLibraryView = xbmc.getCondVisibility("Window.IsActive(Videos)") and xbmc.getCondVisibility("Window.Is(Videos)")
        
        if IsVideoLibraryView:
          
          ExperimentalForcePresetViews = xbmc.getCondVisibility("Skin.HasSetting(ExperimentalForcePresetViews)")
          
          if ExperimentalForcePresetViews:
            IsVideoDb = xbmc.getCondVisibility("String.StartsWith(Container.folderpath,videodb://)")
            IsFilesContent = xbmc.getCondVisibility("Container.Content(Files)")
            
            # movies
            IsMovieContent = xbmc.getCondVisibility("Container.Content(Movies)")
            IsSetsContent = xbmc.getCondVisibility("Container.Content(Sets)")
            
            #tv shows
            IsTvShowsContent = xbmc.getCondVisibility("Container.Content(TvShows)")
            IsSeasonsContent = xbmc.getCondVisibility("Container.Content(Seasons)")
            IsEpisodesContent = xbmc.getCondVisibility("Container.Content(Episodes)")
            
            #genres
            IsGenresContent = xbmc.getCondVisibility("Container.Content(Genres)")
            
            IsSpecialList = xbmc.getCondVisibility("String.StartsWith(Container.FolderPath,special://skin/playlists/)") and xbmc.getCondVisibility("String.Contains(Container.FolderPath,- Special Lists)")
            
            #folder patch movies
            IsSetsMoviesFolderPath = xbmc.getCondVisibility("String.StartsWith(Container.folderpath,videodb://movies/sets/)")
            IsGenresMoviesFolderPath = xbmc.getCondVisibility("String.StartsWith(Container.folderpath,videodb://movies/genres/)")
            IsRecentlyAddedMoviesFolderPath = xbmc.getCondVisibility("String.StartsWith(Container.folderpath,videodb://recentlyaddedmovies/)")
            IsMyListMoviesFolderPath = xbmc.getCondVisibility("String.StartsWith(Container.FolderPath,special://skin/playlists/Movies - Special Lists/_mylist_movies.xsp)")
            
            #folder patch tv shows
            IsGenresTvShowsFolderPath = xbmc.getCondVisibility("String.StartsWith(Container.folderpath,videodb://tvshows/genres/)")
            IsMyListTvShowsFolderPath = xbmc.getCondVisibility("String.StartsWith(Container.FolderPath,special://skin/playlists/TV Shows - Special Lists/_mylist_tvshows.xsp)")
            IsRecentlyAddedEpisodesFolderPath = xbmc.getCondVisibility("String.StartsWith(Container.folderpath,videodb://recentlyaddedepisodes/)")
            
            switchToView = False
            
            # 901 = "Text"
            #  52 = "Modern" (aka Episodes View)
            # 500 = "Wall 2x7"
            # 909 = "Wall 3x9"
            # 908 = "Wall 4x12"
            # 508 = "Fanart"
            
            # standard video files without db entries
            #if IsFilesContent and not IsVideoDb:
            #  switchToView = 52
            
            # global movies
            if IsMovieContent and not IsSetsMoviesFolderPath and not IsGenresMoviesFolderPath and not IsRecentlyAddedMoviesFolderPath and not IsSpecialList and not IsMyListMoviesFolderPath:
              switchToView = 500
            
            # movies: "my list"
            if IsMovieContent and IsMyListMoviesFolderPath:
              switchToView = 508
            # movie genres: list movies of selected genre
            if IsMovieContent and IsGenresMoviesFolderPath:
              switchToView = 500
            # movie sets: list sets
            if IsSetsContent:
              switchToView = 500
            # movie sets: list movies of set
            if IsMovieContent and IsSetsMoviesFolderPath:
              switchToView = 508
            # recently added movies
            if IsRecentlyAddedMoviesFolderPath:
              switchToView = 508
            
            # global tv shows
            if IsTvShowsContent and not IsGenresTvShowsFolderPath and not IsSpecialList and not IsMyListTvShowsFolderPath:
              switchToView = 508
            # global tv show seasons
            if IsSeasonsContent and not IsGenresTvShowsFolderPath:
              switchToView = 901
            
            # tv shows genres: list shows in selected genre
            if IsTvShowsContent and IsGenresTvShowsFolderPath:
              switchToView = 508
            # tv show seasons: list seasons in selected genre
            if IsSeasonsContent and IsGenresTvShowsFolderPath:
              switchToView = 901
            # tv shows: list shows in "my list"
            if IsTvShowsContent and IsMyListTvShowsFolderPath:
              switchToView = 508
              
            # episodes: viewtype change not necessary due to fixed 52 ("Modern"), but always change to sort by episode no + ascending
            if IsEpisodesContent and IsVideoDb and not IsRecentlyAddedEpisodesFolderPath:
              isSortMethodEpisode = xbmc.getCondVisibility('String.IsEqual(Container.SortMethod,$LOCALIZE[20359])')#20359="Episode"
              sortMethod = xbmc.getInfoLabel("Container.SortMethod")
              if not isSortMethodEpisode:
                xbmc.executebuiltin('Container.SetSortMethod(23)')#23=Episode (conflicting Forum+Wiki Info about this. 23 works for Krypton)
                xbmc.sleep(25)#short wait before SortDirection check
              if xbmc.getCondVisibility('Container.SortDirection(descending)'):
                xbmc.executebuiltin('Container.SetSortDirection()')
            
            
            if switchToView:
              viewLabelCompare = ''
              if switchToView == 500:
                viewLabelCompare = 'Wall 2x7'
              if switchToView == 909:
                viewLabelCompare = 'Wall 3x9'
              if switchToView == 908:
                viewLabelCompare = 'Wall 4x12'
              if switchToView == 508:
                viewLabelCompare = xbmc.getLocalizedString(31029)
              if switchToView == 901:
                viewLabelCompare = 'Text'
              if switchToView == 52:
                viewLabelCompare = 'Modern'
              
              
              currentView = xbmc.getInfoLabel("Container.ViewMode")
            
            if switchToView and currentView != viewLabelCompare:
              xbmc.executebuiltin('Container.SetViewMode('+str(switchToView)+')')
              if switchToView == 508 and showParentDirItems:
                # if we just switched to fanart view (508)
                # wait a bit before proceeding to ParentFolder Item skip
                xbmc.sleep(25)
          
          
          if showParentDirItems:
            # Move-Skip ParentFolderItem for Fanart View (on content load)
            FanartViewHasFocus = xbmc.getCondVisibility("Control.HasFocus(508)")
            if FanartViewHasFocus:
              FanartViewListItemIsParentFolder = xbmc.getCondVisibility("Container(508).ListItem.IsParentFolder")
              if FanartViewListItemIsParentFolder:
                xbmc.executebuiltin("Control.Move(508,1)")





  # INTERVAL 2
  
  if TimerInterval_2_Enabled and (timeNow - TimerInterval_2) > TimerInterval_2_ResetSec:
    TimerInterval_2 = time.time()
    
    IsScrolling = xbmc.getCondVisibility("Container.Scrolling")
    if not IsScrolling:
      
      showParentDirItems = xbmc.getCondVisibility("System.GetBool(filelists.showparentdiritems)")
      
      if showParentDirItems:
        # Move-Skip ParentFolderItem for Fanart View (on Idle)
        FanartViewHasFocus = xbmc.getCondVisibility("Control.HasFocus(508)")
        if FanartViewHasFocus:# and bool(xbmc.getCondVisibility("Window.Is(Videos)"))
          if playerMonitor.skinIsACZG:
            FanartViewListItemIsParentFolder = xbmc.getCondVisibility("Container(508).ListItem.IsParentFolder")
            tmpKodiIdleTime = xbmc.getGlobalIdleTime()
            if FanartViewListItemIsParentFolder and tmpKodiIdleTime > 1:
              xbmc.executebuiltin("Control.Move(508,1)")
      
      
      
      
      
      # --------------------------------------------------------------------------------
      # Clear PlayBackJustStarted / PlayBackJustEnded after X seconds
      # --------------------------------------------------------------------------------
      PlayBackJustStarted = xbmcgui.Window(10000).getProperty('PlayBackJustStarted')
      
      if PlayBackJustStarted == "True":
        tmpTimerDifference = timeNow - playerMonitor.startTimer
        if tmpTimerDifference > float(1.00):
          xbmc.executebuiltin("SetProperty(PlayBackJustStarted,,home)")
      
      PlayBackJustEnded = xbmcgui.Window(10000).getProperty('PlayBackJustEnded')
      
      if PlayBackJustEnded == "True":
        tmpTimerDifference = timeNow - playerMonitor.endTimer
        if tmpTimerDifference > float(1.00):
          xbmc.executebuiltin("SetProperty(PlayBackJustEnded,,home)")
      
      
      
      PlayerHasMedia = xbmc.getCondVisibility("Player.HasMedia")
      PlayerHasVideo = xbmc.getCondVisibility("Player.HasVideo")
      PlayerHasAudio = xbmc.getCondVisibility("Player.HasAudio")
      
      playingVideo = PlayerHasMedia and PlayerHasVideo
      playingAudio = PlayerHasMedia and PlayerHasAudio and not PlayerHasVideo
      
      
      # --------------------------------------------------------------------------------
      # Auto Close VideoOSD/MusicOSD when Idle
      # --------------------------------------------------------------------------------
      if (playingVideo or playingAudio):
        tmpTimerDifference = timeNow - playerMonitor.idleCheckIntervalTimer
        
        if tmpTimerDifference > float(2.50):
          
          playerMonitor.skinIsACZG = xbmc.getSkinDir() == "skin.aczg"
          
          if playerMonitor.skinIsACZG:
            
            tmpKodiIdleTime = xbmc.getGlobalIdleTime()
            
            if tmpKodiIdleTime > 6:
              
              if playerMonitor.isKodi18plus:
                if xbmc.getCondVisibility('Window.IsActive(VideoOSD)') or xbmc.getCondVisibility('Window.IsActive(MusicOSD)'):
                  xbmc.executebuiltin('Dialog.Close(all)')
              else:
                if xbmc.getCondVisibility('Window.IsTopMost(VideoOSD)'):
                  xbmc.executebuiltin('Dialog.Close(VideoOSD)')
                
                if xbmc.getCondVisibility('Window.IsTopMost(MusicOSD)'):
                  xbmc.executebuiltin('Dialog.Close(MusicOSD)')
            
            
            playerMonitor.idleCheckIntervalTimer = time.time()
      
      
      # --------------------------------------------------------------------------------
      # Save Player DB Movie progress %
      # --------------------------------------------------------------------------------
      if playingVideo and playerMonitor.VideoPlayerIsMovieInDb:
        
        tmpTimerDifference = timeNow - playerMonitor.percentageTimer
        
        if tmpTimerDifference > float(5.00):
          
          jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Player.GetProperties","params":{"playerid":1,"properties":["percentage"]},"id":"1"}')
          if not playerMonitor.isKodi19plus:# Python 2
            jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
          jsonQuery = simplejson.loads(jsonQuery)
          
          if not playerMonitor.isKodi19plus:# Python 2
            tmpHasKeyCheck = jsonQuery.has_key('result') and jsonQuery['result'].has_key('percentage')
          else:# Python 3
            tmpHasKeyCheck = 'result' in jsonQuery and 'percentage' in jsonQuery['result']
          if tmpHasKeyCheck:
            playerMonitor.playerPercentage = int(jsonQuery['result']['percentage'])
          
          playerMonitor.percentageTimer = time.time()



      # --------------------------------------------------------------------------------
      # CinemaHelper.UserRating
      # --------------------------------------------------------------------------------
      UserRatingPROCESS = bool(xbmcgui.Window(10000).getProperty('CinemaHelper.UserRating.PROCESS'))
      
      if UserRatingPROCESS:
        UserRatingDbId   = int(xbmcgui.Window(10000).getProperty('CinemaHelper.UserRating.DbId'))
        UserRatingDbType = str(xbmcgui.Window(10000).getProperty('CinemaHelper.UserRating.DbType'))
        UserRatingAction = str(xbmcgui.Window(10000).getProperty('CinemaHelper.UserRating.Action'))
        
        UserRatingIsMovie = UserRatingDbType == "movie"
        UserRatingIsEpisode = UserRatingDbType == "episode"
        UserRatingIsTvShow = UserRatingDbType == "tvshow"
        
        if UserRatingAction and UserRatingDbId and (UserRatingIsMovie or UserRatingIsEpisode or UserRatingIsTvShow):
          
          if UserRatingAction == "WatchListAdd":
            
            if UserRatingIsMovie:
              jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetMovieDetails","params":{"movieid":'+str(UserRatingDbId)+',"userrating":1}}')
              if not playerMonitor.isKodi19plus:# Python 2
                jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
              jsonQuery = simplejson.loads(jsonQuery)
            
            if UserRatingIsEpisode:
              jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":'+str(UserRatingDbId)+',"userrating":1}}')
              if not playerMonitor.isKodi19plus:# Python 2
                jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
              jsonQuery = simplejson.loads(jsonQuery)
            
            if UserRatingIsTvShow:
              jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetTvShowDetails","params":{"tvshowid":'+str(UserRatingDbId)+',"userrating":1}}')
              if not playerMonitor.isKodi19plus:# Python 2
                jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
              jsonQuery = simplejson.loads(jsonQuery)
          
          if UserRatingAction == "WatchListRemove":
            
            if UserRatingIsMovie:
              jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetMovieDetails","params":{"movieid":'+str(UserRatingDbId)+',"userrating":0}}')
              if not playerMonitor.isKodi19plus:# Python 2
                jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
              jsonQuery = simplejson.loads(jsonQuery)
            
            if UserRatingIsEpisode:
              jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":'+str(UserRatingDbId)+',"userrating":0}}')
              if not playerMonitor.isKodi19plus:# Python 2
                jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
              jsonQuery = simplejson.loads(jsonQuery)
            
            if UserRatingIsTvShow:
              jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetTvShowDetails","params":{"tvshowid":'+str(UserRatingDbId)+',"userrating":0}}')
              if not playerMonitor.isKodi19plus:# Python 2
                jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
              jsonQuery = simplejson.loads(jsonQuery)
        
        
        xbmc.executebuiltin("ClearProperty(CinemaHelper.UserRating.PROCESS,home)")
      
      
      
      
      # --------------------------------------------------------------------------------
      # CinemaHelper.WatchedState
      # --------------------------------------------------------------------------------
      
      WatchedStateReloadSkinFlag = bool(xbmcgui.Window(10000).getProperty('CinemaHelper.WatchedState.ReloadSkin'))
      if WatchedStateReloadSkinFlag:
        MovieInformationClosing =  bool(xbmc.getCondVisibility("Window.IsActive(MovieInformation)"))
      
      if WatchedStateReloadSkinFlag and not MovieInformationClosing:
        if bool(xbmc.getCondVisibility("Window.IsVisible(Videos)")):
          xbmc.executebuiltin("ReloadSkin()")
          xbmc.executebuiltin("SetProperty(CinemaHelper.WatchedState.ReloadSkin,,home)")
        else:
          xbmc.executebuiltin("SetProperty(CinemaHelper.WatchedState.ReloadSkin,,home)")
      
      
      WatchedStatePROCESS = bool(xbmcgui.Window(10000).getProperty('CinemaHelper.WatchedState.PROCESS'))
      
      if(WatchedStatePROCESS):
        WatchedStateDbId   = int(xbmcgui.Window(10000).getProperty('CinemaHelper.WatchedState.DbId'))
        WatchedStateDbType = str(xbmcgui.Window(10000).getProperty('CinemaHelper.WatchedState.DbType'))
        WatchedStateAction = str(xbmcgui.Window(10000).getProperty('CinemaHelper.WatchedState.Action'))
        
        WatchedStateIsMovie = WatchedStateDbType == "movie"
        WatchedStateIsEpisode = WatchedStateDbType == "episode"
        
        if WatchedStateAction and WatchedStateDbId and (WatchedStateIsMovie or WatchedStateIsEpisode):
          
          if WatchedStateAction == "SetWatched":
            if WatchedStateIsMovie:
              jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetMovieDetails","params":{"movieid":'+str(WatchedStateDbId)+',"playcount":1,"lastplayed":""}}')
              if not playerMonitor.isKodi19plus:# Python 2
                jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
              jsonQuery = simplejson.loads(jsonQuery)
            if WatchedStateIsEpisode:
              jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":'+str(WatchedStateDbId)+',"playcount":1,"lastplayed":""}}')
              if not playerMonitor.isKodi19plus:# Python 2
                jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
              jsonQuery = simplejson.loads(jsonQuery)
          
          if WatchedStateAction == "SetNotWatched":
            if WatchedStateIsMovie:
              jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetMovieDetails","params":{"movieid":'+str(WatchedStateDbId)+',"playcount":0,"lastplayed":""}}')
              if not playerMonitor.isKodi19plus:# Python 2
                jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
              jsonQuery = simplejson.loads(jsonQuery)
            if WatchedStateIsEpisode:
              jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":'+str(WatchedStateDbId)+',"playcount":0,"lastplayed":""}}')
              if not playerMonitor.isKodi19plus:# Python 2
                jsonQuery = unicode(jsonQuery, 'utf-8', errors='ignore')
              jsonQuery = simplejson.loads(jsonQuery)
              
        
        xbmc.executebuiltin("ClearProperty(CinemaHelper.WatchedState.PROCESS,home)")



#/while


