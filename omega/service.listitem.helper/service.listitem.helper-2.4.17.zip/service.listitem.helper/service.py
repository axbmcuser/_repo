# -*- coding: utf-8 -*-

import xbmc
import xbmcaddon
import xbmcvfs

import arrow
from simplecache import use_cache, SimpleCache
from datetime import datetime

import xbmcgui
import simplejson

import xml.etree.ElementTree as ET

# Script constants
__addon__      = xbmcaddon.Addon()
__addonid__    = __addon__.getAddonInfo('id')
__version__    = __addon__.getAddonInfo('version')
__language__   = __addon__.getLocalizedString
__cwd__        = __addon__.getAddonInfo('path')



home_win = xbmcgui.Window(10000)



# save default settings.xml if not existant for easy user edit

settings_xml = "special://userdata/addon_data/service.listitem.helper/settings.xml"
settings_xml_present = xbmcvfs.exists(settings_xml)
        
if not settings_xml_present:
    omdb_api_key = __addon__.getSetting('omdb_api_key')
    if omdb_api_key:
        __addon__.setSetting(id='omdb_api_key', value=str(omdb_api_key))



def log(txt):
    message = str('%s: %s' % (__addonid__, txt))
    xbmc.log(msg=message, level=xbmc.LOGDEBUG)



def isValidIMDBNumberFormat(value):
    # tt, nm, co, ev, ch, ni
    return value.startswith(('tt', 'nm', 'co', 'ev', 'ch', 'ni'))



class Main:
    
    api_key = None
    cache = None
    
    _addon, _close_called, _omdb, _tmdb, _mdblist = [None] * 5


    def __init__(self, simplecache=None):
        log("version %s started" % __version__)
        
        self.previousitem = ""
        self.selecteditem = ""
        self.dbid = ""
        self.uid = ""
        self.dbype = ""
        self.imdbnumber = ""
        self.imdbnumber_isvalid = False
        self.imdbnumber_corrected = ""
        self.imdbnumber_corrected_isvalid = False
        self.rating = ""
        self.itempath = ""
        self.itemfile = ""
        self.itemfilenameandpath = ""
        
        
        
        self.BuildVersionStr = xbmc.getInfoLabel('System.BuildVersion')
        self.BuildVersionIsBetterUI = self.BuildVersionStr.find("BetterUI") >= 0
        
        
        
        self.videolibrary_itemseparator_default          = ' / ' if not self.BuildVersionIsBetterUI else ' · '
        self.videolibrary_itemseparator_advancedsettings = self.videolibrary_itemseparator_default
        
        self.videolibrary_itemseparator_fallback         = ' / ' if self.BuildVersionIsBetterUI else ""
        
        self.videolibrary_itemseparator_replacewith      = ' · '
        
        
        
        # check for potential advancedsettings.xml user value of "videolibrary.itemseparator"
        
        xmlpath = "special://userdata/advancedsettings.xml"
        xmlfile = xbmcvfs.translatePath(xmlpath)
        
        if xmlfile and xbmcvfs.exists(xmlfile):
            try:
                tree = ET.parse(xmlfile)
                root = tree.getroot()
                
                if tree is not None and root is not None:
                    for itemseparator in root.findall("./videolibrary/itemseparator"):
                        if itemseparator.text:
                            self.videolibrary_itemseparator_advancedsettings = str(itemseparator.text)
                            break
            except:
                log('advancedsettings.xml parsing error')
        
        
        
        self.studio = ""
        self.genre = ""
        self.director = ""
        self.writer = ""
        
        self.localratings = ""
        
        self.cache = SimpleCache()
        
        self.monitor = xbmc.Monitor()
        self.run_service()


    def run_service(self):
        while not self.monitor.abortRequested():
            if self.monitor.waitForAbort(0.7):
                break
            
            IsScrolling = xbmc.getCondVisibility('Container.Scrolling | Container.OnPrevious | Container.OnNext | Container.OnScrollPrevious | Container.OnScrollNext')
            
            if not IsScrolling:
                
                IsVideoLibraryView = xbmc.getCondVisibility("Window.IsActive(Videos) + Window.Is(Videos)")
                IsMovieInfoDialogView = xbmc.getCondVisibility("Window.IsActive(MovieInformation) + Window.Is(MovieInformation)")
                
                IsMovieContent = xbmc.getCondVisibility("Container.Content(Movies)")
                IsTvShowsContent = xbmc.getCondVisibility("Container.Content(TvShows)")
                IsSeasonsContent = xbmc.getCondVisibility("Container.Content(Seasons)")
                IsEpisodesContent = xbmc.getCondVisibility("Container.Content(Episodes)")
                
                IsValidContent = IsMovieContent or IsTvShowsContent or IsSeasonsContent or IsEpisodesContent
                
                IsAddon = xbmc.getInfoLabel("Container.PluginName") or xbmc.getInfoLabel("Container.FolderPath").startswith('plugin://')
                IsTMDbHelper = xbmc.getInfoLabel("Container.PluginName") == "plugin.video.themoviedb.helper" or xbmc.getInfoLabel("Container.FolderPath").startswith('plugin://plugin.video.themoviedb.helper')
            
            tmpCheckCondition = not IsScrolling and IsValidContent and (IsVideoLibraryView or IsMovieInfoDialogView) and (not IsAddon or IsTMDbHelper)
            
            if tmpCheckCondition:
                
                tmp_imdb = xbmc.getInfoLabel("ListItem.IMDBNumber")
                tmp_dbid = xbmc.getInfoLabel("ListItem.DBID")
                
                add_item_string = '_'+tmp_dbid if tmp_dbid else ''
                
                if not add_item_string:
                    tmp_currentitem = xbmc.getInfoLabel("ListItem.CurrentItem")
                    add_item_string = '_i'+tmp_currentitem if tmp_currentitem else ''
                    
                self.selecteditem = tmp_imdb+add_item_string
                
                if (self.selecteditem and self.selecteditem != self.previousitem):
                    self.previousitem = self.selecteditem
                    
                    tmpDBTYPE = xbmc.getInfoLabel("ListItem.DBTYPE")
                    tmpIMDBNumber = tmp_imdb
                    
                    IsDbTypeMovie = tmpDBTYPE == 'movie' and not xbmc.getCondVisibility("ListItem.IsFolder") and tmpIMDBNumber
                    IsDbTypeTvShow = tmpDBTYPE == 'tvshow' and tmpIMDBNumber
                    IsDbTypeSeason = tmpDBTYPE == 'season'
                    IsDbTypeEpisode = tmpDBTYPE == 'episode'
                    
                    IsValidDbType = IsDbTypeMovie or IsDbTypeTvShow or IsDbTypeSeason or IsDbTypeEpisode
                    
                    if (IsValidDbType):
                        
                        # 20366 = "* All seasons"
                        if IsDbTypeSeason and xbmc.getInfoLabel("ListItem.Label") == xbmc.getLocalizedString(20366) and xbmc.getInfoLabel("ListItem.TvShowDBID"):
                            self.dbid = xbmc.getInfoLabel("ListItem.TvShowDBID")
                        else:
                            self.dbid = tmp_dbid
                        
                        self.uid = self.dbid+'_'+tmp_imdb
                        
                        self.dbtype = tmpDBTYPE
                        self.imdbnumber = tmp_imdb
                        self.imdbnumber_corrected = tmp_imdb
                        self.imdbnumber_isvalid = False
                        self.imdbnumber_corrected_isvalid = False
                        self.rating = xbmc.getInfoLabel("ListItem.rating")
                        self.rating = self.rating if not self.rating.isspace() else None
                        
                        
                        
                        self.localratings = ""
                        
                        
                        if IsDbTypeMovie and self.dbid:
                            
                            jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"VideoLibrary.GetMovieDetails","params":{"movieid":'+str(self.dbid)+',"properties":["ratings"]},"id":1}')
                            
                            jsonResultHasRatings = False
                            
                            jsonQuery = simplejson.loads(jsonQuery)
                            
                            jsonResultHasRatings = 'result' in jsonQuery and 'moviedetails' in jsonQuery['result'] and 'ratings' in jsonQuery['result']['moviedetails']
                            
                            if jsonResultHasRatings:
                                self.localratings = jsonQuery['result']['moviedetails']['ratings']
                        
                        
                        if IsDbTypeMovie and self.imdbnumber:
                            
                            # Validate self.imdbnumber_corrected. ListItem.IMDBNumber sometimes wrong (some scraper wrongly put their own id into this property)
                            # tt, nm, co, ev, ch, ni
                            isValidIMDBNumber = isValidIMDBNumberFormat(self.imdbnumber_corrected)
                            
                            if isValidIMDBNumber:
                                self.imdbnumber_isvalid = True
                                self.imdbnumber_corrected_isvalid = True
                            
                            if not isValidIMDBNumber and self.dbid:
                                
                                jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"VideoLibrary.GetMovieDetails","params":{"movieid":'+str(self.dbid)+',"properties":["uniqueid"]},"id":1}')
                                jsonQuery = simplejson.loads(jsonQuery)
                                
                                jsonResultHasUniqueIds = False
                                jsonResultHasUniqueIdImdb = False
                                jsonResultHasUniqueIdUnknown = False
                                
                                # Check if result contains uniqueid as expected
                                jsonResultHasUniqueIds = 'result' in jsonQuery and 'moviedetails' in jsonQuery['result'] and 'uniqueid' in jsonQuery['result']['moviedetails']
                                
                                # only process if uniqueids found at all
                                if jsonResultHasUniqueIds:
                                    # Check if result contains uniqueid['imdb'] as hoped
                                    jsonResultHasUniqueIdImdb = 'imdb' in jsonQuery['result']['moviedetails']['uniqueid']
                                    
                                    if jsonResultHasUniqueIdImdb:
                                        self.imdbnumber_corrected = str(jsonQuery['result']['moviedetails']['uniqueid']['imdb'])
                                        self.imdbnumber_corrected_isvalid = True
                                    else:
                                        jsonResultHasUniqueIdUnknown = 'unknown' in jsonQuery['result']['moviedetails']['uniqueid']
                                        if jsonResultHasUniqueIdUnknown:
                                            tempImdbOld = self.imdbnumber_corrected
                                            self.imdbnumber_corrected = str(jsonQuery['result']['moviedetails']['uniqueid']['unknown'])
                                            
                                            # Validate self.imdbnumber_corrected again
                                            isValidIMDBNumber = isValidIMDBNumberFormat(self.imdbnumber_corrected)
                                            
                                            if isValidIMDBNumber:
                                                self.imdbnumber_corrected_isvalid = True
                                                pass
                                            else:
                                                # restore initial value because correct failed
                                                self.imdbnumber_corrected = tempImdbOld
                                                del tempImdbOld
                                        else:
                                            pass
                                
                                del jsonResultHasUniqueIds
                                del jsonResultHasUniqueIdImdb
                                del jsonResultHasUniqueIdUnknown
                        
                        
                        
                        self.itempath = ""
                        self.itemfile = ""
                        self.itemfilenameandpath = ""
                        self.studio = ""
                        self.genre = ""
                        self.director = ""
                        self.writer = ""
                        
                        try:
                            InfoLabel = xbmc.getInfoLabel("ListItem.Path")
                            self.itempath = InfoLabel if InfoLabel else ""
                            
                            InfoLabel = xbmc.getInfoLabel("ListItem.FileName")
                            self.itemfile = InfoLabel if InfoLabel else ""
                            
                            InfoLabel = xbmc.getInfoLabel("ListItem.FileNameAndPath")
                            self.itemfilenameandpath = InfoLabel if InfoLabel else ""
                            
                            InfoLabel = xbmc.getInfoLabel("ListItem.Studio")
                            self.studio = InfoLabel if InfoLabel else ""
                            
                            InfoLabel = xbmc.getInfoLabel("ListItem.Genre")
                            self.genre = InfoLabel if InfoLabel else ""
                            
                            InfoLabel = xbmc.getInfoLabel("ListItem.Director")
                            self.director = InfoLabel if InfoLabel else ""
                            
                            InfoLabel = xbmc.getInfoLabel("ListItem.Writer")
                            self.writer = InfoLabel if InfoLabel else ""
                            
                        except:
                            pass
                        
                        self.set_helper_values()
                        
            else:
                my_container_id = home_win.getProperty('ListItemHelper.WidgetContainerId')
                my_container_window = home_win.getProperty('ListItemHelper.WidgetContainerWindowName')
                
                IsScrollingWidget = xbmc.getCondVisibility("Container("+my_container_id+").Scrolling | Container("+my_container_id+").OnPrevious | Container("+my_container_id+").OnNext | Container("+my_container_id+").OnScrollPrevious | Container("+my_container_id+").OnScrollNext")
                
                if not IsScrolling and not IsScrollingWidget:
                    
                    ContainerParentWindowActive = xbmc.getCondVisibility("Window.IsActive("+my_container_window+") + Window.Is("+my_container_window+")")
                    ContainerCheckedAndFocus = my_container_id and my_container_window and xbmc.getCondVisibility("Control.HasFocus("+my_container_id+")")
                    IsVideoLibraryOrMovieInfoDialogView = xbmc.getCondVisibility("Window.IsActive(Videos) | Window.IsActive(MovieInformation)")
                    
                    IsAddon = xbmc.getInfoLabel("Container("+my_container_id+").PluginName") or xbmc.getInfoLabel("Container("+my_container_id+").FolderPath").startswith('plugin://')
                    IsTMDbHelper = xbmc.getInfoLabel("Container("+my_container_id+").PluginName") == "plugin.video.themoviedb.helper" or xbmc.getInfoLabel("Container("+my_container_id+").FolderPath").startswith('plugin://plugin.video.themoviedb.helper')
                
                tmpCheckCondition = not IsScrolling and not IsScrollingWidget and not IsVideoLibraryOrMovieInfoDialogView and ContainerParentWindowActive and ContainerCheckedAndFocus and (not IsAddon or IsTMDbHelper)
                
                if tmpCheckCondition:
                    
                    tmp_imdb = xbmc.getInfoLabel("Container("+my_container_id+").ListItem.IMDBNumber")
                    tmp_dbid = xbmc.getInfoLabel("Container("+my_container_id+").ListItem.DBID")
                    
                    add_item_string = '_'+tmp_dbid if tmp_dbid else ''
                    
                    if not add_item_string:
                        tmp_currentitem = xbmc.getInfoLabel("Container("+my_container_id+").ListItem.CurrentItem")
                        add_item_string = '_i'+tmp_currentitem if tmp_currentitem else ''
                    
                    self.selecteditem = tmp_imdb+add_item_string
                    
                    if (self.selecteditem and self.selecteditem != self.previousitem):
                        self.previousitem = self.selecteditem
                        
                        tmpDBTYPE = xbmc.getInfoLabel("Container("+my_container_id+").ListItem.DBTYPE")
                        tmpIMDBNumber = tmp_imdb
                        
                        IsDbTypeMovie = tmpDBTYPE == 'movie' and not xbmc.getCondVisibility("Container("+my_container_id+").ListItem.IsFolder") and tmpIMDBNumber
                        IsDbTypeTvShow = tmpDBTYPE == 'tvshow' and tmpIMDBNumber
                        IsDbTypeSeason = tmpDBTYPE == 'season'
                        IsDbTypeEpisode = tmpDBTYPE == 'episode'
                        
                        IsValidDbType = IsDbTypeMovie or IsDbTypeTvShow or IsDbTypeEpisode
                        
                        if (IsValidDbType):
                            
                            # 20366 = "* All seasons"
                            if IsDbTypeSeason and xbmc.getInfoLabel("Container("+my_container_id+").ListItem.Label") == xbmc.getLocalizedString(20366) and xbmc.getInfoLabel("Container("+my_container_id+").ListItem.TvShowDBID"):
                                self.dbid = xbmc.getInfoLabel("Container("+my_container_id+").ListItem.TvShowDBID")
                            else:
                                self.dbid = tmp_dbid
                            
                            self.uid = self.dbid+'_'+tmp_imdb
                            
                            self.dbtype = tmpDBTYPE
                            self.imdbnumber = tmp_imdb
                            self.imdbnumber_corrected = tmp_imdb
                            self.imdbnumber_isvalid = False
                            self.imdbnumber_corrected_isvalid = False
                            self.rating = xbmc.getInfoLabel("Container("+my_container_id+").ListItem.rating")
                            self.rating = self.rating if not self.rating.isspace() else None
                            
                            
                            
                            self.localratings = ""
                            
                            
                            if IsDbTypeMovie and self.dbid:
                                
                                jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"VideoLibrary.GetMovieDetails","params":{"movieid":'+str(self.dbid)+',"properties":["ratings"]},"id":1}')
                                
                                jsonResultHasRatings = False
                                
                                jsonQuery = simplejson.loads(jsonQuery)
                                
                                jsonResultHasRatings = 'result' in jsonQuery and 'moviedetails' in jsonQuery['result'] and 'ratings' in jsonQuery['result']['moviedetails']
                                
                                if jsonResultHasRatings:
                                    self.localratings = jsonQuery['result']['moviedetails']['ratings']
                            
                            
                            if IsDbTypeMovie and self.imdbnumber:
                                
                                # Validate self.imdbnumber_corrected. ListItem.IMDBNumber sometimes wrong (some scraper wrongly put their own id into this property)
                                # tt, nm, co, ev, ch, ni
                                isValidIMDBNumber = isValidIMDBNumberFormat(self.imdbnumber_corrected)
                                
                                if isValidIMDBNumber:
                                    self.imdbnumber_isvalid = True
                                    self.imdbnumber_corrected_isvalid = True
                                
                                if not isValidIMDBNumber and self.dbid:
                                  
                                  jsonQuery = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"VideoLibrary.GetMovieDetails","params":{"movieid":'+str(self.dbid)+',"properties":["uniqueid"]},"id":1}')
                                  jsonQuery = simplejson.loads(jsonQuery)
                                  
                                  jsonResultHasUniqueIds = False
                                  jsonResultHasUniqueIdImdb = False
                                  jsonResultHasUniqueIdUnknown = False
                                  
                                  # Check if result contains uniqueid as expected
                                  jsonResultHasUniqueIds = 'result' in jsonQuery and 'moviedetails' in jsonQuery['result'] and 'uniqueid' in jsonQuery['result']['moviedetails']
                                  
                                  # only process if uniqueids found at all
                                  if jsonResultHasUniqueIds:
                                      # Check if result contains uniqueid['imdb'] as hoped
                                      jsonResultHasUniqueIdImdb = 'imdb' in jsonQuery['result']['moviedetails']['uniqueid']
                                      
                                      if jsonResultHasUniqueIdImdb:
                                          self.imdbnumber_corrected = str(jsonQuery['result']['moviedetails']['uniqueid']['imdb'])
                                          self.imdbnumber_corrected_isvalid = True
                                      else:
                                        jsonResultHasUniqueIdUnknown = 'unknown' in jsonQuery['result']['moviedetails']['uniqueid']
                                        if jsonResultHasUniqueIdUnknown:
                                            tempImdbOld = self.imdbnumber_corrected
                                            self.imdbnumber_corrected = str(jsonQuery['result']['moviedetails']['uniqueid']['unknown'])
                                            
                                            # Validate self.imdbnumber_corrected again
                                            isValidIMDBNumber = isValidIMDBNumberFormat(self.imdbnumber_corrected)
                                            
                                            if isValidIMDBNumber:
                                                self.imdbnumber_corrected_isvalid = True
                                                pass
                                            else:
                                                # restore initial value because correct failed
                                                self.imdbnumber_corrected = tempImdbOld
                                                del tempImdbOld
                                        else:
                                            pass
                                  
                                  del jsonResultHasUniqueIds
                                  del jsonResultHasUniqueIdImdb
                                  del jsonResultHasUniqueIdUnknown
                            
                            
                            
                            self.itempath = ""
                            self.itemfile = ""
                            self.itemfilenameandpath = ""
                            self.studio = ""
                            self.genre = ""
                            self.director = ""
                            self.writer = ""
                            
                            try:
                                InfoLabel = xbmc.getInfoLabel("Container("+my_container_id+").ListItem.Path")
                                self.itempath = InfoLabel if InfoLabel else ""
                                
                                InfoLabel = xbmc.getInfoLabel("Container("+my_container_id+").ListItem.FileName")
                                self.itemfile = InfoLabel if InfoLabel else ""
                                
                                InfoLabel = xbmc.getInfoLabel("Container("+my_container_id+").ListItem.FileNameAndPath")
                                self.itemfilenameandpath = InfoLabel if InfoLabel else ""
                                
                                InfoLabel = xbmc.getInfoLabel("Container("+my_container_id+").ListItem.Studio")
                                self.studio = InfoLabel if InfoLabel else ""
                                
                                InfoLabel = xbmc.getInfoLabel("Container("+my_container_id+").ListItem.Genre")
                                self.genre = InfoLabel if InfoLabel else ""
                                
                                InfoLabel = xbmc.getInfoLabel("Container("+my_container_id+").ListItem.Director")
                                self.director = InfoLabel if InfoLabel else ""
                                
                                InfoLabel = xbmc.getInfoLabel("Container("+my_container_id+").ListItem.Writer")
                                self.writer = InfoLabel if InfoLabel else ""
                                
                            except:
                                pass
                            
                            self.set_helper_values()
            
            
            tmpCheckCondition = xbmc.getCondVisibility("Skin.HasSetting(ExperimentalShowNtsFile) + Window.IsVisible(1103) + Window.IsVisible(MovieInformation)") and not home_win.getProperty('ListItemHelper.internalnotes') and not home_win.getProperty('ListItemHelper.internalnotes2') and self.dbid
            
            if tmpCheckCondition:
                try:
                    if(self.itempath):
                        tmp_internalnotes = ""
                        tmp_internalnotes2 = ""
                        
                        media_file = xbmcvfs.translatePath(self.itemfilenameandpath)
                        
                        media_file_present = xbmcvfs.exists(media_file)
                        if(media_file_present):
                            try:
                                f = xbmcvfs.File(media_file)
                                fsizegb = round(f.size()/1e+9,2)
                                f.close()
                                tmp_internalnotes = tmp_internalnotes + '[COLOR=orange]' + str(fsizegb) + ' GB    \"' + str(self.itemfile) + '\"[/COLOR]'
                            except:
                                pass
                            
                            try:
                                st = xbmcvfs.Stat(media_file)
                                modified = st.st_mtime()
                                modified = datetime.fromtimestamp(modified)
                                tmp_internalnotes = tmp_internalnotes + '[COLOR=orange]    ' + str(modified) + '[/COLOR]'
                            except:
                                pass
                        
                        notes_file = xbmcvfs.translatePath(self.itempath)+'.rls-rmx.nts'
                        
                        notes_file_present = xbmcvfs.exists(notes_file)
                        if(notes_file_present):
                            try:
                                f = xbmcvfs.File(notes_file)
                                if(f):
                                    b = f.read()
                                    b = b.replace('"', r'\"')
                                    tmp_internalnotes = tmp_internalnotes + '[CR][CR]' + str(b)
                                f.close()
                            except:
                                pass
                        
                        nfo_file = xbmcvfs.translatePath(self.itempath)+'.nfo.nts'
                        
                        nfo_file_present = xbmcvfs.exists(nfo_file)
                        if(nfo_file_present):
                            try:
                                f = xbmcvfs.File(nfo_file)
                                if(f):
                                    b = f.read()
                                    b = b.replace('"', r'\"')
                                    tmp_internalnotes = tmp_internalnotes + '[CR][CR][CR][CR]' + str(b) + '[CR][CR]'
                                f.close()
                            except:
                                pass
                        
                        mediainfo_file = xbmcvfs.translatePath(self.itempath)+'.mediainfo.nts'
                        
                        mediainfo_file_present = xbmcvfs.exists(mediainfo_file)
                        if(mediainfo_file_present):
                            try:
                                f = xbmcvfs.File(mediainfo_file)
                                if(f):
                                    b = f.read()
                                    b = b.replace('"', r'\"')
                                    tmp_internalnotes2 = tmp_internalnotes2 + str(b)
                                f.close()
                            except:
                                pass
                        
                        home_win.setProperty('ListItemHelper.internalnotes', tmp_internalnotes)
                        home_win.setProperty('ListItemHelper.internalnotes2', tmp_internalnotes2)
                except:
                    home_win.setProperty('ListItemHelper.internalnotes', 'N/A')
                    home_win.setProperty('ListItemHelper.internalnotes2', 'N/A')
    #run_service end


    def set_helper_values(self):
        #log('set_helper_values')
        
        home_win.clearProperty('ListItemHelper.DBID')
        home_win.clearProperty('ListItemHelper.UID')
        
        # studio genre writer director
        
        home_win.clearProperty('ListItemHelper.genre.formatted')
        home_win.clearProperty('ListItemHelper.writer.formatted')
        home_win.clearProperty('ListItemHelper.director.formatted')
        
        
        
        home_win.clearProperty('ListItemHelper.studio.1')
        home_win.clearProperty('ListItemHelper.genre.1')
        home_win.clearProperty('ListItemHelper.writer.1')
        home_win.clearProperty('ListItemHelper.director.1')
        
        home_win.clearProperty('ListItemHelper.studio.2')
        home_win.clearProperty('ListItemHelper.genre.2')
        home_win.clearProperty('ListItemHelper.writer.2')
        home_win.clearProperty('ListItemHelper.director.2')
        
        home_win.clearProperty('ListItemHelper.studio.3')
        home_win.clearProperty('ListItemHelper.genre.3')
        home_win.clearProperty('ListItemHelper.writer.3')
        home_win.clearProperty('ListItemHelper.director.3')
        
        home_win.clearProperty('ListItemHelper.studio.4')
        home_win.clearProperty('ListItemHelper.genre.4')
        home_win.clearProperty('ListItemHelper.writer.4')
        home_win.clearProperty('ListItemHelper.director.4')
        
        home_win.clearProperty('ListItemHelper.studio.5')
        home_win.clearProperty('ListItemHelper.genre.5')
        home_win.clearProperty('ListItemHelper.writer.5')
        home_win.clearProperty('ListItemHelper.director.5')
        
        home_win.clearProperty('ListItemHelper.studio.6')
        home_win.clearProperty('ListItemHelper.genre.6')
        home_win.clearProperty('ListItemHelper.writer.6')
        home_win.clearProperty('ListItemHelper.director.6')
        
        home_win.clearProperty('ListItemHelper.studio.7')
        home_win.clearProperty('ListItemHelper.genre.7')
        home_win.clearProperty('ListItemHelper.writer.7')
        home_win.clearProperty('ListItemHelper.director.7')
        
        home_win.clearProperty('ListItemHelper.studio.8')
        home_win.clearProperty('ListItemHelper.genre.8')
        home_win.clearProperty('ListItemHelper.writer.8')
        home_win.clearProperty('ListItemHelper.director.8')
        
        home_win.clearProperty('ListItemHelper.studio.9')
        home_win.clearProperty('ListItemHelper.genre.9')
        home_win.clearProperty('ListItemHelper.writer.9')
        home_win.clearProperty('ListItemHelper.director.9')
        
        home_win.clearProperty('ListItemHelper.studio.10')
        home_win.clearProperty('ListItemHelper.genre.10')
        home_win.clearProperty('ListItemHelper.writer.10')
        home_win.clearProperty('ListItemHelper.director.10')
        
        
        
        
        
        
        if self.genre:
            if not self.videolibrary_itemseparator_default == self.videolibrary_itemseparator_advancedsettings and self.videolibrary_itemseparator_advancedsettings in self.genre:
                splitString = self.genre.split(self.videolibrary_itemseparator_advancedsettings)
            else:
                if self.videolibrary_itemseparator_default in self.genre or not self.videolibrary_itemseparator_fallback:
                    splitString = self.genre.split(self.videolibrary_itemseparator_default)
                else:
                    splitString = self.genre.split(self.videolibrary_itemseparator_fallback)
            if splitString:
                indexNo = 1
                allitems = ""
                for item in splitString:
                    home_win.setProperty('ListItemHelper.genre.'+str(indexNo), str(item))
                    allitems = allitems + self.videolibrary_itemseparator_replacewith + str(item) if indexNo > 1 else str(item)
                    indexNo += 1
                    if indexNo > 10:
                        break
                home_win.setProperty('ListItemHelper.genre.formatted', str(allitems))
        
        if self.studio:
            if not self.videolibrary_itemseparator_default == self.videolibrary_itemseparator_advancedsettings and self.videolibrary_itemseparator_advancedsettings in self.studio:
                splitString = self.studio.split(self.videolibrary_itemseparator_advancedsettings)
            else:
                if self.videolibrary_itemseparator_default in self.studio or not self.videolibrary_itemseparator_fallback:
                    splitString = self.studio.split(self.videolibrary_itemseparator_default)
                else:
                    splitString = self.studio.split(self.videolibrary_itemseparator_fallback)
            if splitString:
                indexNo = 1
                for item in splitString:
                    home_win.setProperty('ListItemHelper.studio.'+str(indexNo), str(item))
                    indexNo += 1
                    if indexNo > 10:
                        break
        
        if self.writer:
            if not self.videolibrary_itemseparator_default == self.videolibrary_itemseparator_advancedsettings and self.videolibrary_itemseparator_advancedsettings in self.writer:
                splitString = self.writer.split(self.videolibrary_itemseparator_advancedsettings)
            else:
                if self.videolibrary_itemseparator_default in self.writer or not self.videolibrary_itemseparator_fallback:
                    splitString = self.writer.split(self.videolibrary_itemseparator_default)
                else:
                    splitString = self.writer.split(self.videolibrary_itemseparator_fallback)
            if splitString:
                indexNo = 1
                allitems = ""
                for item in splitString:
                    home_win.setProperty('ListItemHelper.writer.'+str(indexNo), str(item))
                    allitems = allitems + self.videolibrary_itemseparator_replacewith + str(item) if indexNo > 1 else str(item)
                    indexNo += 1
                    if indexNo > 10:
                        break
                home_win.setProperty('ListItemHelper.writer.formatted', str(allitems))
        
        if self.director:
            if not self.videolibrary_itemseparator_default == self.videolibrary_itemseparator_advancedsettings and self.videolibrary_itemseparator_advancedsettings in self.director:
                splitString = self.director.split(self.videolibrary_itemseparator_advancedsettings)
            else:
                if self.videolibrary_itemseparator_default in self.director or not self.videolibrary_itemseparator_fallback:
                    splitString = self.director.split(self.videolibrary_itemseparator_default)
                else:
                    splitString = self.director.split(self.videolibrary_itemseparator_fallback)
            if splitString:
                indexNo = 1
                allitems = ""
                for item in splitString:
                    home_win.setProperty('ListItemHelper.director.'+str(indexNo), str(item))
                    allitems = allitems + self.videolibrary_itemseparator_replacewith + str(item) if indexNo > 1 else str(item)
                    indexNo += 1
                    if indexNo > 10:
                        break
                home_win.setProperty('ListItemHelper.director.formatted', str(allitems))
        
        
        
        # OMDb
        home_win.clearProperty('ListItemHelper.rating.rottentomatoes.percent')
        home_win.clearProperty('ListItemHelper.rating.rottentomatoes.image')
        home_win.clearProperty('ListItemHelper.rating.rottentomatoes.url')
        home_win.clearProperty('ListItemHelper.rating.rottentomatoes.audience')
        home_win.clearProperty('ListItemHelper.rating.metacritic.percent')
        home_win.clearProperty('ListItemHelper.rating.imdb.percent')
        home_win.clearProperty('ListItemHelper.rating.imdb')
        home_win.clearProperty('ListItemHelper.rating.imdb.votes')
        home_win.clearProperty('ListItemHelper.rating.highestScaleTo5')
        home_win.clearProperty('ListItemHelper.rating.highestScaleTo10')
        home_win.clearProperty('ListItemHelper.rating.highestScaleTo100')
        rottentomatoesPercent         = None
        rottentomatoesAudiencePercent = None
        metacriticPercent             = None
        imdbPercent                   = None
        
        home_win.clearProperty('ListItemHelper.awards')
        home_win.clearProperty('ListItemHelper.revenue.boxoffice')
        
        # TMDb
        home_win.clearProperty('ListItemHelper.TMDBID')
        home_win.clearProperty('ListItemHelper.TVDBID')
        home_win.clearProperty('ListItemHelper.budget')
        home_win.clearProperty('ListItemHelper.budget.million')
        home_win.clearProperty('ListItemHelper.budget.formatted')
        home_win.clearProperty('ListItemHelper.revenue')
        home_win.clearProperty('ListItemHelper.revenue.million')
        home_win.clearProperty('ListItemHelper.revenue.formatted')
        
        # MDBList
        home_win.clearProperty('ListItemHelper.ageRating.commonsense')
        
        home_win.clearProperty('ListItemHelper.rating.letterboxd')
        home_win.clearProperty('ListItemHelper.rating.letterboxd.percent')
        home_win.clearProperty('ListItemHelper.rating.letterboxd.votes')
        home_win.clearProperty('ListItemHelper.rating.trakt')
        home_win.clearProperty('ListItemHelper.rating.trakt.percent')
        home_win.clearProperty('ListItemHelper.rating.trakt.votes')
        letterboxdPercent             = None
        traktPercent                  = None
        
        # local ratings
        
        home_win.clearProperty('ListItemHelper.listitem.rating.tomatometerallcritics')
        home_win.clearProperty('ListItemHelper.listitem.rating.tomatometerallcritics.scaleTo100')
        home_win.clearProperty('ListItemHelper.listitem.votes.tomatometerallcritics')
        home_win.clearProperty('ListItemHelper.listitem.rating.rottentomatoes')
        home_win.clearProperty('ListItemHelper.listitem.rating.rottentomatoes.scaleTo100')
        home_win.clearProperty('ListItemHelper.listitem.votes.rottentomatoes')
        
        home_win.clearProperty('ListItemHelper.listitem.rating.tomatometerallaudience')
        home_win.clearProperty('ListItemHelper.listitem.rating.tomatometerallaudience.scaleTo100')
        home_win.clearProperty('ListItemHelper.listitem.votes.tomatometerallaudience')
        
        home_win.clearProperty('ListItemHelper.listitem.rating.metacritic')
        home_win.clearProperty('ListItemHelper.listitem.rating.metacritic.scaleTo100')
        home_win.clearProperty('ListItemHelper.listitem.votes.metacritic')
        
        home_win.clearProperty('ListItemHelper.listitem.rating.metascore')
        home_win.clearProperty('ListItemHelper.listitem.rating.metascore.scaleTo100')
        home_win.clearProperty('ListItemHelper.listitem.votes.metascore')
        
        home_win.clearProperty('ListItemHelper.listitem.rating.imdb')
        home_win.clearProperty('ListItemHelper.listitem.rating.imdb.scaleTo100')
        home_win.clearProperty('ListItemHelper.listitem.votes.imdb')
        
        home_win.clearProperty('ListItemHelper.listitem.rating.letterboxd')
        home_win.clearProperty('ListItemHelper.listitem.rating.letterboxd.scaleTo100')
        home_win.clearProperty('ListItemHelper.listitem.votes.letterboxd')
        
        home_win.clearProperty('ListItemHelper.listitem.rating.trakt')
        home_win.clearProperty('ListItemHelper.listitem.rating.trakt.scaleTo100')
        home_win.clearProperty('ListItemHelper.listitem.votes.trakt')
        
        
        # Internal Notes files
        home_win.clearProperty('ListItemHelper.internalnotes')
        home_win.clearProperty('ListItemHelper.internalnotes2')
        
        
        # General
        home_win.setProperty('ListItemHelper.DBID', str(self.dbid))
        home_win.setProperty('ListItemHelper.UID', str(self.uid))
        home_win.setProperty('ListItemHelper.IMDBNumber', str(self.imdbnumber))
        home_win.setProperty('ListItemHelper.IMDBNumber.isValid', str(self.imdbnumber_isvalid))
        home_win.setProperty('ListItemHelper.IMDBNumber.corrected', str(self.imdbnumber_corrected))
        home_win.setProperty('ListItemHelper.IMDBNumber.corrected.isValid', str(self.imdbnumber_corrected_isvalid))
        
        
        
        localrating_tomatometerallcritics = False
        localrating_rottentomatoes = False
        localrating_tomatometerallaudience = False
        localrating_metacritic = False
        localrating_metascore = False
        localrating_imdb = False
        localrating_letterboxd = False
        localrating_trakt = False
        
        localrating_tomatometerallcritics_ScaleTo100 = False
        localrating_rottentomatoes_ScaleTo100 = False
        localrating_tomatometerallaudience_ScaleTo100 = False
        localrating_metacritic_ScaleTo100 = False
        localrating_metascore_ScaleTo100 = False
        localrating_imdb_ScaleTo100 = False
        localrating_letterboxd_ScaleTo100 = False
        localrating_trakt_ScaleTo100 = False
        
        if self.dbtype == 'movie' and self.localratings:
            # tomatometerallcritics
            ratingkeyfound = 'tomatometerallcritics' in self.localratings
            if ratingkeyfound:
                ratingkeyfound = 'rating' in self.localratings['tomatometerallcritics']
                if ratingkeyfound:
                    localrating_tomatometerallcritics = round(self.localratings['tomatometerallcritics']['rating'],1)
                    localrating_tomatometerallcritics_ScaleTo100 = int(round(float(localrating_tomatometerallcritics)*10))
                    home_win.setProperty('ListItemHelper.listitem.rating.tomatometerallcritics', str(localrating_tomatometerallcritics))
                    home_win.setProperty('ListItemHelper.listitem.rating.tomatometerallcritics.scaleTo100', str(localrating_tomatometerallcritics_ScaleTo100))
                ratingkeyfound = 'votes' in self.localratings['tomatometerallcritics']
                if ratingkeyfound:
                    home_win.setProperty('ListItemHelper.listitem.votes.tomatometerallcritics', str(round(self.localratings['tomatometerallcritics']['votes'])))
            # rottentomatoes
            ratingkeyfound = 'rottentomatoes' in self.localratings
            if ratingkeyfound:
                ratingkeyfound = 'rating' in self.localratings['rottentomatoes']
                if ratingkeyfound:
                    localrating_rottentomatoes = round(self.localratings['rottentomatoes']['rating'],1)
                    localrating_rottentomatoes_ScaleTo100 = int(round(float(localrating_rottentomatoes)*10))
                    home_win.setProperty('ListItemHelper.listitem.rating.rottentomatoes', str(localrating_rottentomatoes))
                    home_win.setProperty('ListItemHelper.listitem.rating.rottentomatoes.scaleTo100', str(localrating_rottentomatoes_ScaleTo100))
                ratingkeyfound = 'votes' in self.localratings['rottentomatoes']
                if ratingkeyfound:
                    home_win.setProperty('ListItemHelper.listitem.votes.rottentomatoes', str(round(self.localratings['rottentomatoes']['votes'])))
            # tomatometerallaudience
            ratingkeyfound = 'tomatometerallaudience' in self.localratings
            if ratingkeyfound:
                ratingkeyfound = 'rating' in self.localratings['tomatometerallaudience']
                if ratingkeyfound:
                    localrating_tomatometerallaudience = round(self.localratings['tomatometerallaudience']['rating'],1)
                    localrating_tomatometerallaudience_ScaleTo100 = int(round(float(localrating_tomatometerallaudience)*10))
                    home_win.setProperty('ListItemHelper.listitem.rating.tomatometerallaudience', str(localrating_tomatometerallaudience))
                    home_win.setProperty('ListItemHelper.listitem.rating.tomatometerallaudience.scaleTo100', str(localrating_tomatometerallaudience_ScaleTo100))
                ratingkeyfound = 'votes' in self.localratings['tomatometerallaudience']
                if ratingkeyfound:
                    home_win.setProperty('ListItemHelper.listitem.votes.tomatometerallaudience', str(round(self.localratings['tomatometerallaudience']['votes'])))
            # metacritic
            ratingkeyfound = 'metacritic' in self.localratings
            if ratingkeyfound:
                ratingkeyfound = 'rating' in self.localratings['metacritic']
                if ratingkeyfound:
                    localrating_metacritic = round(self.localratings['metacritic']['rating'],1)
                    localrating_metacritic_ScaleTo100 = int(round(float(localrating_metacritic)*10))
                    home_win.setProperty('ListItemHelper.listitem.rating.metacritic', str(localrating_metacritic))
                    home_win.setProperty('ListItemHelper.listitem.rating.metacritic.scaleTo100', str(localrating_metacritic_ScaleTo100))
                ratingkeyfound = 'votes' in self.localratings['metacritic']
                if ratingkeyfound:
                    home_win.setProperty('ListItemHelper.listitem.votes.metacritic', str(round(self.localratings['metacritic']['votes'])))
            # metascore
            ratingkeyfound = 'metascore' in self.localratings
            if ratingkeyfound:
                ratingkeyfound = 'rating' in self.localratings['metascore']
                if ratingkeyfound:
                    localrating_metascore = round(self.localratings['metascore']['rating'],1)
                    localrating_metascore_ScaleTo100 = int(round(float(localrating_metascore)*10))
                    home_win.setProperty('ListItemHelper.listitem.rating.metascore', str(localrating_metascore))
                    home_win.setProperty('ListItemHelper.listitem.rating.metascore.scaleTo100', str(localrating_metascore_ScaleTo100))
                ratingkeyfound = 'votes' in self.localratings['metascore']
                if ratingkeyfound:
                    home_win.setProperty('ListItemHelper.listitem.votes.metascore', str(round(self.localratings['metascore']['votes'])))
            # imdb
            ratingkeyfound = 'imdb' in self.localratings
            if ratingkeyfound:
                ratingkeyfound = 'rating' in self.localratings['imdb']
                if ratingkeyfound:
                    localrating_imdb = round(self.localratings['imdb']['rating'],1)
                    localrating_imdb_ScaleTo100 = int(round(float(localrating_imdb)*10))
                    home_win.setProperty('ListItemHelper.listitem.rating.imdb', str(localrating_imdb))
                    home_win.setProperty('ListItemHelper.listitem.rating.imdb.scaleTo100', str(localrating_imdb_ScaleTo100))
                ratingkeyfound = 'votes' in self.localratings['imdb']
                if ratingkeyfound:
                    home_win.setProperty('ListItemHelper.listitem.votes.imdb', str(round(self.localratings['imdb']['votes'])))
            # letterboxd
            ratingkeyfound = 'letterboxd' in self.localratings
            if ratingkeyfound:
                ratingkeyfound = 'rating' in self.localratings['letterboxd']
                if ratingkeyfound:
                    localrating_letterboxd = round(self.localratings['letterboxd']['rating'],1)
                    localrating_letterboxd_ScaleTo100 = int(round(float(localrating_letterboxd)*10))
                    home_win.setProperty('ListItemHelper.listitem.rating.letterboxd', str(localrating_letterboxd))
                    home_win.setProperty('ListItemHelper.listitem.rating.letterboxd.scaleTo100', str(localrating_letterboxd_ScaleTo100))
                ratingkeyfound = 'votes' in self.localratings['letterboxd']
                if ratingkeyfound:
                    home_win.setProperty('ListItemHelper.listitem.votes.letterboxd', str(round(self.localratings['letterboxd']['votes'])))
            # trakt
            ratingkeyfound = 'trakt' in self.localratings
            if ratingkeyfound:
                ratingkeyfound = 'rating' in self.localratings['trakt']
                if ratingkeyfound:
                    localrating_trakt = round(self.localratings['trakt']['rating'],1)
                    localrating_trakt_ScaleTo100 = int(round(float(localrating_trakt)*10))
                    home_win.setProperty('ListItemHelper.listitem.rating.trakt', str(localrating_trakt))
                    home_win.setProperty('ListItemHelper.listitem.rating.trakt.scaleTo100', str(localrating_trakt_ScaleTo100))
                ratingkeyfound = 'votes' in self.localratings['trakt']
                if ratingkeyfound:
                    home_win.setProperty('ListItemHelper.listitem.votes.trakt', str(round(self.localratings['trakt']['votes'])))
        
        
        
        MDBListImdb      = None
        MDBListImdbVotes = None
        
        # MDBList
        if self.dbtype == 'movie' and self.imdbnumber_corrected_isvalid:
            self.mdblist_result = self.get_mdblist_details(self.imdbnumber_corrected)
        
        if self.dbtype == 'movie' and self.imdbnumber_corrected_isvalid and self.mdblist_result:
            if 'commonsense' in self.mdblist_result and self.mdblist_result['commonsense']:
                home_win.setProperty('ListItemHelper.ageRating.commonsense', str(self.mdblist_result['commonsense']))
            
            if 'ratings' in self.mdblist_result:
                for rating in self.mdblist_result['ratings']:
                    if 'source' in rating:
                        # letterboxd
                        if rating['source'] == 'letterboxd':
                            if 'value' in rating and rating['value']:
                                home_win.setProperty('ListItemHelper.rating.letterboxd', str(rating['value']))
                            if 'score' in rating and rating['score']:
                                home_win.setProperty('ListItemHelper.rating.letterboxd.percent', str(rating['score']))
                                letterboxdPercent = int(float(rating['score']))
                            if 'votes' in rating and rating['votes']:
                                home_win.setProperty('ListItemHelper.rating.letterboxd.votes', str(rating['votes']))
                        # imdb
                        if rating['source'] == 'imdb':
                            if 'value' in rating and rating['value']:
                                MDBListImdb = True
                                home_win.setProperty('ListItemHelper.rating.imdb', str(rating['value']))
                            if 'score' in rating and rating['score']:
                                home_win.setProperty('ListItemHelper.rating.imdb.percent', str(rating['score']))
                                imdbPercent = int(float(rating['score']))
                            if 'votes' in rating and rating['votes']:
                                MDBListImdbVotes = True
                                home_win.setProperty('ListItemHelper.rating.imdb.votes', str(rating['votes']))
                        # rotten tomatoes
                        if rating['source'] == 'tomatoes':
                            if 'score' in rating and rating['score']:
                                home_win.setProperty('ListItemHelper.rating.rottentomatoes.percent', str(rating['score']))
                                rottentomatoesPercent = int(float(rating['score']))
                        # rotten tomatoes audience
                        if rating['source'] == 'tomatoesaudience':
                            if 'score' in rating and rating['score']:
                                home_win.setProperty('ListItemHelper.rating.rottentomatoes.audience', str(rating['score']))
                                rottentomatoesAudiencePercent = int(float(rating['score']))
                        # metacritic
                        if rating['source'] == 'metacritic':
                            if 'score' in rating and rating['score']:
                                home_win.setProperty('ListItemHelper.rating.metacritic.percent', str(rating['score']))
                                metacriticPercent = int(float(rating['score']))
                        # trakt
                        if rating['source'] == 'trakt':
                            if 'value' in rating and rating['value']:
                                home_win.setProperty('ListItemHelper.rating.trakt', str(rating['value']))
                            if 'score' in rating and rating['score']:
                                home_win.setProperty('ListItemHelper.rating.trakt.percent', str(rating['score']))
                                traktPercent = int(float(rating['score']))
                            if 'votes' in rating and rating['votes']:
                                home_win.setProperty('ListItemHelper.rating.trakt.votes', str(rating['votes']))
        
        
        
        # OMDB
        if self.dbtype == 'movie' and self.imdbnumber_corrected_isvalid:
            self.omdb_result = self.get_omdb_info(self.imdbnumber_corrected)
        
        if self.dbtype == 'movie' and self.imdbnumber_corrected_isvalid and self.omdb_result:
            for key, value in self.omdb_result.items():
                # rotten tomatoes
                if key == "rottentomatoes.rating" and value and not rottentomatoesPercent:
                    home_win.setProperty('ListItemHelper.rating.rottentomatoes.percent', str(value))
                    try:
                        rottentomatoesPercent = int(float(value))
                    except:
                        pass
                if key == "rottentomatoes.image" and value :
                    home_win.setProperty('ListItemHelper.rating.rottentomatoes.image', str(value))
                if key == "rottentomatoes.audience" and value and not rottentomatoesAudiencePercent:
                    home_win.setProperty('ListItemHelper.rating.rottentomatoes.audience', str(value))
                    try:
                        rottentomatoesAudiencePercent = int(float(value))
                    except:
                        pass
                
                # metacritic
                if key == "metacritic.rating" and value and not metacriticPercent:
                    home_win.setProperty('ListItemHelper.rating.metacritic.percent', str(value))
                    try:
                        metacriticPercent = int(float(value))
                    except:
                        pass
                
                # imdb
                if key == "rating.percent.imdb" and value and not imdbPercent:
                    home_win.setProperty('ListItemHelper.rating.imdb.percent', str(value))
                    try:
                        imdbPercent = int(float(value))
                    except:
                        pass
                if key == "rating.imdb" and value and not MDBListImdb:
                    home_win.setProperty('ListItemHelper.rating.imdb', str(value))
                if key == "votes.imdb" and value and not MDBListImdbVotes:
                    home_win.setProperty('ListItemHelper.rating.imdb.votes', str(value))
                
                if key == "rottentomatoes.url" and value :
                    home_win.setProperty('ListItemHelper.rating.rottentomatoes.url', str(value))
                # awards
                if key == "awards" and value :
                    home_win.setProperty('ListItemHelper.awards', str(value))
                # boxoffice
                if key == "boxoffice" and value :
                    home_win.setProperty('ListItemHelper.revenue.boxoffice', str(value))
        
        
        percentList                       = []
        
        
        
        if rottentomatoesPercent:         percentList.append(rottentomatoesPercent)
        if rottentomatoesAudiencePercent: percentList.append(rottentomatoesAudiencePercent)
        if metacriticPercent:             percentList.append(metacriticPercent)
        if imdbPercent:                   percentList.append(imdbPercent)
        if letterboxdPercent:             percentList.append(letterboxdPercent)
        if traktPercent:                  percentList.append(traktPercent)
        
        
        localRating = localrating_tomatometerallcritics_ScaleTo100
        if localRating: percentList.append(localRating)
        localRating = localrating_rottentomatoes_ScaleTo100
        if localRating: percentList.append(localRating)
        
        localRating = localrating_tomatometerallaudience_ScaleTo100
        if localRating: percentList.append(localRating)
        
        localRating = localrating_metacritic_ScaleTo100
        if localRating: percentList.append(localRating)
        localRating = localrating_metascore_ScaleTo100
        if localRating: percentList.append(localRating)
        
        localRating = localrating_imdb_ScaleTo100
        if localRating: percentList.append(localRating)
        
        localRating = localrating_letterboxd_ScaleTo100
        if localRating: percentList.append(localRating)
        
        localRating = localrating_trakt_ScaleTo100
        if localRating: percentList.append(localRating)
        
        
        
        try:
            if self.rating:               percentList.append(int(float(self.rating)*10))
            
            highestPercent = max(percentList) if percentList else None
            
            highestPercentTo5Rating          = float(highestPercent)/20 if highestPercent else None
            highestPercentTo10Rating         = float(highestPercent)/10 if highestPercent else None
            highestPercentTo100Rating        = float(highestPercent)    if highestPercent else None
            
            if highestPercent:
                home_win.setProperty('ListItemHelper.rating.highestScaleTo5', str(highestPercentTo5Rating))
                home_win.setProperty('ListItemHelper.rating.highestScaleTo10', str(highestPercentTo10Rating))
                home_win.setProperty('ListItemHelper.rating.highestScaleTo100', str(highestPercentTo100Rating))
        
        except:
            pass
        
        
        
        # TMDB
        if self.dbtype == 'movie' and self.imdbnumber_corrected_isvalid:
            self.tmdb_result = self.get_tmdb_details(self.imdbnumber_corrected)
        
        if self.dbtype == 'movie' and self.imdbnumber_corrected_isvalid and self.tmdb_result:
            for key, value in self.tmdb_result.items():
                # tmdb_id
                if key == "tmdb_id" and value :
                    home_win.setProperty('ListItemHelper.TMDBID', str(value))
                # tvdb_id
                if key == "tvdb_id" and value :
                    home_win.setProperty('ListItemHelper.TVDBID', str(value))
                # budget
                if key == "budget" and value :
                    try:
                        tmpval = float(int(value))
                        if (tmpval > 0) :
                            home_win.setProperty('ListItemHelper.budget', str(value))
                            try:
                                tmpval = round(tmpval/1000000, 2)
                                if tmpval.is_integer() :
                                    tmpval = '%.0f' % tmpval
                                else :
                                    if (tmpval >= 2 and tmpval < 10) :
                                        tmpval = round(tmpval,1)
                                        tmpval = '%.0f' % tmpval
                                    elif (tmpval >= 10) :
                                        tmpval = round(tmpval,0)
                                        tmpval = '%.0f' % tmpval
                                home_win.setProperty('ListItemHelper.budget.million', str(tmpval))
                            except:
                                pass
                    except:
                        pass
                if key == "budget.formatted" and value :
                    try:
                        if (value != '0') :
                             home_win.setProperty('ListItemHelper.budget.formatted', str(value))
                    except:
                        pass
                # revenue
                if key == "revenue" and value :
                    try:
                        tmpval = float(int(value))
                        if (tmpval > 0) :
                            home_win.setProperty('ListItemHelper.revenue', str(value))
                            try:
                                tmpval = round(tmpval/1000000, 2)
                                if tmpval.is_integer() :
                                    tmpval = '%.0f' % tmpval
                                else :
                                    if (tmpval >= 2 and tmpval < 10) :
                                        tmpval = round(tmpval,1)
                                        tmpval = '%.0f' % tmpval
                                    elif (tmpval >= 10) :
                                        tmpval = round(tmpval,0)
                                        tmpval = '%.0f' % tmpval
                                home_win.setProperty('ListItemHelper.revenue.million', str(tmpval))
                            except:
                                pass
                    except:
                        pass
                if key == "revenue.formatted" and value :
                    try:
                        if (value != '0') :
                            home_win.setProperty('ListItemHelper.revenue.formatted', str(value))
                    except:
                        pass
        
        
        
        
    #set_helper_values end

    def get_omdb_info(self, imdb_id="", title="", year="", content_type=""):
        '''Get (kodi compatible formatted) metadata from OMDB, including Rotten tomatoes details'''
        #title = title.split(" (")[0]  # strip year appended to title
        result = {}
        if imdb_id:
            result = self.omdb.get_details_by_imdbid(imdb_id)
        '''
        elif title and content_type in ["seasons", "season", "episodes", "episode", "tvshows", "tvshow"]:
            result = self.omdb.get_details_by_title(title, "", "tvshows")
        elif title and year:
            result = self.get_details_by_title(title, year, content_type)
         if result and result.get("status"):
             result["status"] = self.translate_string(result["status"])
         if result and result.get("runtime"):
             result["runtime"] = result["runtime"] / 60
             result.update(self.get_duration(result["runtime"]))
        '''
        return result


    def get_tmdb_details(self, imdb_id="", tvdb_id="", title="", year="", media_type="",
                         preftype="", manual_select=False, ignore_cache=False):
        '''returns details from tmdb'''
        result = {}
        if imdb_id:
            result = self.tmdb.get_videodetails_by_externalid(
                imdb_id, "imdb_id")
        '''
        elif tvdb_id:
            result = self.tmdb.get_videodetails_by_externalid(
                tvdb_id, "tvdb_id")
        elif title and media_type in ["movies", "setmovies", "movie"]:
            result = self.tmdb.search_movie(
                title, year, manual_select=manual_select, ignore_cache=ignore_cache)
        elif title and media_type in ["tvshows", "tvshow"]:
            result = self.tmdb.search_tvshow(
                title, year, manual_select=manual_select, ignore_cache=ignore_cache)
        elif title:
            result = self.tmdb.search_video(
                title, year, preftype=preftype, manual_select=manual_select, ignore_cache=ignore_cache)
        if result and result.get("status"):
            result["status"] = self.translate_string(result["status"])
        if result and result.get("runtime"):
            result["runtime"] = result["runtime"] / 60
            result.update(self.get_duration(result["runtime"]))
        '''
        return result


    def get_mdblist_details(self, imdb_id="", tvdb_id="", title="", year="", media_type="",
                         preftype="", manual_select=False, ignore_cache=False):
        '''returns details from mdblist'''
        result = {}
        if imdb_id:
            result = self.mdblist.get_details_by_externalid(imdb_id, "imdb_id")
        return result


    @property
    def omdb(self):
        '''public omdb object - for lazy loading'''
        if not self._omdb:
            from lib.omdb import ListItemHelperOmdb
            self._omdb = ListItemHelperOmdb(self.cache)
        return self._omdb


    @property
    def tmdb(self):
        '''public Tmdb object - for lazy loading'''
        if not self._tmdb:
            from lib.tmdb import Tmdb
            self._tmdb = Tmdb(self.cache)
        return self._tmdb


    @property
    def mdblist(self):
        '''public mdblist object - for lazy loading'''
        if not self._mdblist:
            from lib.mdblist import mdblist
            self._mdblist = mdblist(self.cache)
        return self._mdblist


if (__name__ == "__main__"):
    Main()


log('script finished.')

