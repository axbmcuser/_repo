import xbmc
from datetime import date, timedelta

Date_Today = date.today().isoformat()

date_x_days_ago = (date.today() - timedelta(days=60)).isoformat()
xbmc.executebuiltin(f'Skin.SetString(Rolling_Dates_TV_Shows_Streaming,{date_x_days_ago})')

xbmc.executebuiltin(f'Skin.SetString(Rolling_Dates_Last_Execute,{str(Date_Today)})')