import xbmc, xbmcaddon

iso_code = ""

LANGUAGES = (
    'ar-AE', 'ar-SA', 'be-BY', 'bg-BG', 'bn-BD', 'ca-ES', 'ch-GU', 'cs-CZ', 'da-DK', 'de-AT', 'de-CH',
    'de-DE', 'el-GR', 'en-AU', 'en-CA', 'en-GB', 'en-IE', 'en-NZ', 'en-US', 'eo-EO', 'es-ES', 'es-MX',
    'et-EE', 'eu-ES', 'fa-IR', 'fi-FI', 'fr-CA', 'fr-FR', 'gl-ES', 'he-IL', 'hi-IN', 'hu-HU', 'id-ID',
    'it-IT', 'ja-JP', 'ka-GE', 'kk-KZ', 'kn-IN', 'ko-KR', 'lt-LT', 'lv-LV', 'ml-IN', 'ms-MY', 'ms-SG',
    'nb-NO', 'nl-NL', 'no-NO', 'pl-PL', 'pt-BR', 'pt-PT', 'ro-RO', 'ru-RU', 'si-LK', 'sk-SK', 'sl-SI',
    'sr-RS', 'sv-SE', 'ta-IN', 'te-IN', 'th-TH', 'tl-PH', 'tr-TR', 'uk-UA', 'vi-VN', 'zh-CN', 'zh-HK',
    'zh-TW', 'zu-ZA', 'hr-HR')

if xbmc.getCondVisibility('!System.HasAddon(plugin.video.themoviedb.helper)'):
    xbmc.executebuiltin('InstallAddon(plugin.video.themoviedb.helper)')
elif xbmc.getCondVisibility('!System.AddonIsEnabled(plugin.video.themoviedb.helper)'):
    xbmc.executebuiltin('EnableAddon(plugin.video.themoviedb.helper)')

if xbmc.getCondVisibility('System.HasAddon(plugin.video.themoviedb.helper) + System.AddonIsEnabled(plugin.video.themoviedb.helper)'):
    
    tmdb_helper = xbmcaddon.Addon('plugin.video.themoviedb.helper')
    language = tmdb_helper.getSetting('language')
    
    if language:
        try:
            iso_code = LANGUAGES[int(language)][-2:]
        except:
            pass


if xbmc.getCondVisibility('!String.IsEqual(Skin.String(TMDB_Helper_Region),'+iso_code+')'):
    
    xbmc.executebuiltin('Skin.SetString(TMDB_Helper_Region,'+str(iso_code)+')')