# Automatic Views

# translate old settings to new settings
import xbmc









try:
    ForcePresetViewsMoviesCategories = xbmc.getInfoLabel('Skin.String(ForcePresetViewsMoviesCategories)')
    if ForcePresetViewsMoviesCategories:
        ForcePresetViewsMoviesCategoriesArr = ForcePresetViewsMoviesCategories.split(',',4)
        
        if int(ForcePresetViewsMoviesCategoriesArr[0]) >= 50:
            xbmc.executebuiltin('Skin.SetString(Auto_Views_Movies_Category_A,'+str(ForcePresetViewsMoviesCategoriesArr[0])+')')
                
        if int(ForcePresetViewsMoviesCategoriesArr[1]) >= 50:
            xbmc.executebuiltin('Skin.SetString(Auto_Views_Movies_Category_B,'+str(ForcePresetViewsMoviesCategoriesArr[1])+')')
                
        if int(ForcePresetViewsMoviesCategoriesArr[2]) >= 50:
            xbmc.executebuiltin('Skin.SetString(Auto_Views_Movies_Category_C,'+str(ForcePresetViewsMoviesCategoriesArr[2])+')')
                
        if int(ForcePresetViewsMoviesCategoriesArr[3]) >= 50:
            xbmc.executebuiltin('Skin.SetString(Auto_Views_Movies_Category_D,'+str(ForcePresetViewsMoviesCategoriesArr[3])+')')
                
except:
    pass

xbmc.executebuiltin('Skin.Reset(ForcePresetViewsMoviesCategories)')









try:
    ForcePresetViewsTvShowsCategories = xbmc.getInfoLabel('Skin.String(ForcePresetViewsTvShowsCategories)')
    if ForcePresetViewsTvShowsCategories:
        ForcePresetViewsTvShowsCategoriesArr = ForcePresetViewsTvShowsCategories.split(',',5)
        
        if int(ForcePresetViewsTvShowsCategoriesArr[0]) >= 50:
            xbmc.executebuiltin('Skin.SetString(Auto_Views_TV_Shows_Category_A,'+str(ForcePresetViewsTvShowsCategoriesArr[0])+')')
                
        if int(ForcePresetViewsTvShowsCategoriesArr[1]) >= 50:
            xbmc.executebuiltin('Skin.SetString(Auto_Views_TV_Shows_Category_B,'+str(ForcePresetViewsTvShowsCategoriesArr[1])+')')
                
        if int(ForcePresetViewsTvShowsCategoriesArr[2]) >= 50:
            xbmc.executebuiltin('Skin.SetString(Auto_Views_TV_Shows_Category_C,'+str(ForcePresetViewsTvShowsCategoriesArr[2])+')')
                
        if int(ForcePresetViewsTvShowsCategoriesArr[3]) >= 50:
            xbmc.executebuiltin('Skin.SetString(Auto_Views_TV_Shows_Category_D,'+str(ForcePresetViewsTvShowsCategoriesArr[3])+')')
                
        if int(ForcePresetViewsTvShowsCategoriesArr[4]) >= 50:
            xbmc.executebuiltin('Skin.SetString(Auto_Views_TV_Shows_Category_E,'+str(ForcePresetViewsTvShowsCategoriesArr[4])+')')
                
except:
    pass

xbmc.executebuiltin('Skin.Reset(ForcePresetViewsTvShowsCategories)')









try:
    ForcePresetViewsMusicPicturesCategories = xbmc.getInfoLabel('Skin.String(ForcePresetViewsMusicPicturesCategories)')
    if ForcePresetViewsMusicPicturesCategories:
        ForcePresetViewsMusicPicturesCategoriesArr = ForcePresetViewsMusicPicturesCategories.split(',',3)
        
        if int(ForcePresetViewsMusicPicturesCategoriesArr[0]) >= 50:
            xbmc.executebuiltin('Skin.SetString(Auto_Views_Music_Pictures_Category_A,'+str(ForcePresetViewsMusicPicturesCategoriesArr[0])+')')
                
        if int(ForcePresetViewsMusicPicturesCategoriesArr[1]) >= 50:
            xbmc.executebuiltin('Skin.SetString(Auto_Views_Music_Pictures_Category_B,'+str(ForcePresetViewsMusicPicturesCategoriesArr[1])+')')
                
        if int(ForcePresetViewsMusicPicturesCategoriesArr[2]) >= 50:
            xbmc.executebuiltin('Skin.SetString(Auto_Views_Music_Pictures_Category_C,'+str(ForcePresetViewsMusicPicturesCategoriesArr[2])+')')
                
except:
    pass

xbmc.executebuiltin('Skin.Reset(ForcePresetViewsMusicPicturesCategories)')









try:
    ForcePresetViewsGlobalMiscCategories = xbmc.getInfoLabel('Skin.String(ForcePresetViewsGlobalMiscCategories)')
    if ForcePresetViewsGlobalMiscCategories:
        ForcePresetViewsGlobalMiscCategoriesArr = ForcePresetViewsGlobalMiscCategories.split(',',5)
        
        if int(ForcePresetViewsGlobalMiscCategoriesArr[0]) >= 50:
            xbmc.executebuiltin('Skin.SetString(Auto_Views_Global_Misc_Category_A,'+str(ForcePresetViewsGlobalMiscCategoriesArr[0])+')')
                
        if int(ForcePresetViewsGlobalMiscCategoriesArr[1]) >= 50:
            xbmc.executebuiltin('Skin.SetString(Auto_Views_Global_Misc_Category_B,'+str(ForcePresetViewsGlobalMiscCategoriesArr[1])+')')
                
        if int(ForcePresetViewsGlobalMiscCategoriesArr[2]) >= 50:
            xbmc.executebuiltin('Skin.SetString(Auto_Views_Global_Misc_Category_C,'+str(ForcePresetViewsGlobalMiscCategoriesArr[2])+')')
                
        if int(ForcePresetViewsGlobalMiscCategoriesArr[3]) >= 50:
            xbmc.executebuiltin('Skin.SetString(Auto_Views_Global_Misc_Category_D,'+str(ForcePresetViewsGlobalMiscCategoriesArr[3])+')')
                
        if int(ForcePresetViewsGlobalMiscCategoriesArr[4]) >= 50:
            xbmc.executebuiltin('Skin.SetString(Auto_Views_Global_Misc_Category_E,'+str(ForcePresetViewsGlobalMiscCategoriesArr[4])+')')
                
except:
    pass

xbmc.executebuiltin('Skin.Reset(ForcePresetViewsGlobalMiscCategories)')








