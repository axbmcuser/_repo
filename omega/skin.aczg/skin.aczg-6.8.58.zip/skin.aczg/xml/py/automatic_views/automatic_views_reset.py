# -*- coding: utf-8 -*-

import xbmc, xbmcgui

are_you_sure = xbmcgui.Dialog().yesno('View IDs · Reset',"Resetting all View IDs to default.[CR][CR]Continue?")

if are_you_sure:
    
    categories = ['Global_Misc','Movies','TV_Shows','Music_Pictures']
    
    for cat in range(len(categories)):
        
        category = categories[cat]
        
        defaults_string = xbmc.getInfoLabel('$VAR[Auto_Views_'+category+'_Defaults]')
        defaults_split = defaults_string.split(',',6)
        
        for i in range(len(defaults_split)):
            reset_tmp = 'Auto_Views_'+category+'_Category_'+chr(ord('@')+i+1)
            xbmc.executebuiltin('Skin.Reset('+reset_tmp+')')
    
    
    
    
    xbmc.executebuiltin('Notification("View IDs · Reset",View IDs have been reset to default,5000)')