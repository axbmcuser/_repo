# -*- coding: utf-8 -*-

import xbmc, xbmcgui, os, sys




category = ""
args = sys.argv
for arg in args:
    if arg != os.path.basename(__file__):
        
        if arg.startswith('category='):
            category = arg[9:]



option_list_defaults = []

if category:
    
    defaults_string = xbmc.getInfoLabel('$VAR[Auto_Views_'+category+'_Defaults]')
    defaults_split = defaults_string.split(',',6)
    
    for i in range(len(defaults_split)):
        option_list_defaults.append(defaults_split[i])



option_list = []
for i in range(len(option_list_defaults)):
    append_tmp = 'Auto_Views_'+category+'_Category_'+chr(ord('@')+i+1)
    option_list.append(append_tmp)



if category:
    
    header = xbmc.getInfoLabel('$VAR[Auto_Views_'+category+'_Label]')
    setting = 'Auto_Views_'+category
    
    options_string = ""
    
    for i in range(len(option_list_defaults)):
        
        option_tmp_setting = option_list[i]
        option_tmp_default = str(option_list_defaults[i])
        
        option_tmp_label = xbmc.getInfoLabel('$VAR['+option_tmp_setting+']')
        option_tmp_current = xbmc.getInfoLabel('Skin.String('+option_tmp_setting+')')
        
        if not option_tmp_current:
            option_tmp_current = option_tmp_default
            xbmc.executebuiltin('Skin.SetString('+option_tmp_setting+',"'+str(option_tmp_current)+'")')
        
        add_spaces = '  '   if len(option_tmp_current) == 2 else ''
        add_spaces = '    ' if len(option_tmp_current) < 2 else add_spaces
        
        default_localized = xbmc.getInfoLabel('$LOCALIZE[13278]')
        default_string = '      [LIGHT][COLOR=grey2]('+default_localized+': '+option_tmp_default+')[/COLOR][/LIGHT]'
        
        options_string = options_string+'"option='+option_tmp_label+'     [COLOR=selected][LIGHT]ID:[/LIGHT]  '+option_tmp_current+''+add_spaces+'[/COLOR]'+default_string+'","value='+option_tmp_setting+'",'
    
    
    xbmc.executebuiltin('RunScript("special://skin/xml/py/automatic_views/automatic_views.py","header='+header+'","setting='+setting+'","category='+category+'",'+options_string+')')
