# -*- coding: utf-8 -*-

import xbmc, xbmcgui, os, sys



title = ''
dialog_select_input_list = []
dialog_select_input_list_values = []


skip_further_options_and_values = False
args = sys.argv
for arg in args:
    if arg != os.path.basename(__file__):
        
        if arg.startswith('header='):
            title = arg[7:]
        
        if arg.startswith('category='):
            category = arg[9:]
       
        if arg.startswith('setting='):
            setting = arg[8:]
        
        if arg.startswith('option=') and arg[7:] and not skip_further_options_and_values:
            dialog_select_input_list.append(arg[7:])
        elif arg.startswith('option=') and not arg[7:] and not skip_further_options_and_values:
            skip_further_options_and_values = True
        
        if arg.startswith('value=') and not skip_further_options_and_values:
            dialog_select_input_list_values.append(arg[6:])



skin_string_setting = xbmc.getInfoLabel('Skin.String('+setting+')')





reset_label = '[COLOR=redwarning][Reset][/COLOR] View IDs of this section    '
dialog_select_input_list.append(reset_label)
dialog_select_input_list_values.append('reset')



if len(dialog_select_input_list) >= 1:
    select_dialog = xbmcgui.Dialog().select(title, dialog_select_input_list)
    
    
    
    if not select_dialog is None and select_dialog >= 0:
        
        out_string = dialog_select_input_list_values[select_dialog]
        
        
        if skin_string_setting != out_string:
            
            
            
            if setting and "Auto_Views_" in setting and out_string:
                
                
                dialog_header = xbmc.getInfoLabel('$VAR[Auto_Views_'+category+'_Label]')
                
                if out_string != 'reset':
                    
                    numeric_string = xbmc.getInfoLabel('Skin.String('+out_string+')')
                    
                    numeric_header = 'View ID:   '+xbmc.getInfoLabel('$VAR['+out_string+']').rstrip()
                    
                    numeric_dialog = xbmcgui.Dialog().numeric(0,numeric_header,numeric_string)
                    
                    if numeric_dialog and not numeric_dialog is None:
                        
                        if int(numeric_dialog) >= 50 and int(numeric_dialog) <= 999:
                            
                            xbmc.executebuiltin('Skin.SetString('+out_string+',"'+str(numeric_dialog)+'")')
                            
                        else:
                            xbmc.executebuiltin('Notification('+numeric_header+',Invalid ID,5000)')
                    
                    
                    
                else:
                        are_you_sure = xbmcgui.Dialog().yesno(dialog_header+' · Reset',"Resetting "+dialog_header+" to default.[CR][CR]Continue?")
                        if are_you_sure:
                            
                            defaults_string = xbmc.getInfoLabel('$VAR[Auto_Views_'+category+'_Defaults]')
                            defaults_split = defaults_string.split(',',6)
                            
                            for i in range(len(defaults_split)):
                                reset_tmp = 'Auto_Views_'+category+'_Category_'+chr(ord('@')+i+1)
                                xbmc.executebuiltin('Skin.Reset('+reset_tmp+')')
                            
                            xbmc.executebuiltin('Notification('+dialog_header+',View IDs have been reset to default,5000)')
                
                
                
                
                
                xbmc.executebuiltin('RunScript("special://skin/xml/py/automatic_views/automatic_views_open.py","category='+category+'")')
