# -*- coding: utf-8 -*-

import xbmc, xbmcgui

are_you_sure = xbmcgui.Dialog().yesno('Widgets · Reset',"Resetting all Widgets to default.[CR][CR]Continue?")

if are_you_sure:
    
    
    
    xbmc.executebuiltin('Skin.Reset(Home_Widget_Movies_Hide)')
    xbmc.executebuiltin('Skin.Reset(Home_Widget_Music_Hide)')
    xbmc.executebuiltin('Skin.Reset(Home_Widget_TV_Shows_Hide)')
    
    
    
    xbmc.executebuiltin('Skin.SetString(Home_Widget_Movies_1,recently_added_movies)')
    xbmc.executebuiltin('Skin.SetString(Home_Widget_Movies_2,in_progress_movies)')
    xbmc.executebuiltin('Skin.SetString(Home_Widget_Movies_3,random_movies)')
    xbmc.executebuiltin('Skin.SetString(Home_Widget_Movies_4,none)')
    xbmc.executebuiltin('Skin.SetString(Home_Widget_Movies_5,none)')
    
    xbmc.executebuiltin('Skin.SetString(Home_Widget_TV_Shows_1,recently_added_tvshows)')
    xbmc.executebuiltin('Skin.SetString(Home_Widget_TV_Shows_2,in_progress_tvshows)')
    xbmc.executebuiltin('Skin.SetString(Home_Widget_TV_Shows_3,random_tvshows)')
    xbmc.executebuiltin('Skin.SetString(Home_Widget_TV_Shows_4,none)')
    xbmc.executebuiltin('Skin.SetString(Home_Widget_TV_Shows_5,none)')
    
    xbmc.executebuiltin('Skin.SetString(Home_Widget_Music_1,recently_played_albums)')
    xbmc.executebuiltin('Skin.SetString(Home_Widget_Music_2,recently_added_albums)')
    xbmc.executebuiltin('Skin.SetString(Home_Widget_Music_3,random_albums)')
    xbmc.executebuiltin('Skin.SetString(Home_Widget_Music_4,none)')
    xbmc.executebuiltin('Skin.SetString(Home_Widget_Music_5,none)')
    
    
    
    xbmc.executebuiltin('Skin.Reset(HomepageHideRecentlyPlayedLiveTV)')
    xbmc.executebuiltin('Skin.Reset(Home_Widget_Weather_Hide)')
    xbmc.executebuiltin('Skin.Reset(HomepageHideWidgetFavorites)')
    xbmc.executebuiltin('Skin.Reset(Home_Widgets_Auto_Reveal_Slots_Disable)')
    xbmc.executebuiltin('Skin.Reset(Home_Widgets_Auto_Activate_Slots_Disable)')
    
    
    
    xbmc.executebuiltin('Notification("Widgets · Reset",Widgets have been reset to default,5000)')