# -*- coding: utf-8 -*-

import xbmc
import xbmcgui
import time

try:
    xbmc.executebuiltin('ActivateWindow(1184)')
    show_changelog = xbmcgui.Dialog().yesno("Confluence ZEITGEIST updated","","$LOCALIZE[15067][LIGHT]$INFO[Window(Home).Property(NewVersionInfoTimeout_Label)][/LIGHT]","Changelog")
    if show_changelog:
        xbmc.executebuiltin('ActivateWindow(1186)')
except:
    pass