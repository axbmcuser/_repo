# -*- coding: utf-8 -*-

import xbmc
import xbmcgui

skinzoom = '0'
xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Settings.SetSettingValue", "params": {"setting":"lookandfeel.skinzoom","value":'+skinzoom+'}, "id": 1}')
xbmcgui.Window(10000).setProperty('CinemaHelper.GetSettingValue.lookandfeel.skinzoom',skinzoom)
xbmc.executebuiltin('Skin.SetString(lookandfeel.skinzoom,'+skinzoom+')')
xbmc.sleep(300)
xbmc.executebuiltin('ReloadSkin()')
xbmc.sleep(150)
xbmc.executebuiltin('Notification(Cinemascope Mode,[B]Disabled[/B]  Skin-Zoom 0%  No Mask,2000,DefaultIconInfo.png)')