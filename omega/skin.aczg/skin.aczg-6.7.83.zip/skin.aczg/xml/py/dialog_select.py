# -*- coding: utf-8 -*-

import xbmc, xbmcgui, os, sys



title = ''
dialog_select_input_list = []
dialog_select_input_list_values = []


args = sys.argv
for arg in args:
    if arg != os.path.basename(__file__):
        if arg.startswith('header='):
            title = arg[7:]
        if arg.startswith('setting='):
            setting = arg[8:]
        if arg.startswith('option='):
            dialog_select_input_list.append(arg[7:])
        if arg.startswith('value='):
            dialog_select_input_list_values.append(arg[6:])



skin_string_setting = xbmc.getInfoLabel('Skin.String('+setting+')')

preselect_item = -1



for i in range(len(dialog_select_input_list)):
    if dialog_select_input_list_values[i] == skin_string_setting:
        preselect_item = i

if len(dialog_select_input_list) >= 1:
    select_dialog = xbmcgui.Dialog().select(title, dialog_select_input_list, preselect=preselect_item)
    
    if not select_dialog is None and select_dialog >= 0:
        
        out_string = dialog_select_input_list_values[select_dialog]
        
        if skin_string_setting != out_string:
            
            xbmc.executebuiltin('Skin.SetString('+setting+',"'+str(out_string)+'")')
            
            if setting == "uiColorVariant":
                if out_string == "":
                    xbmc.executebuiltin('RunScript("special://skin/xml/py/uicolor_set0.py")')
                elif out_string == "1":
                    xbmc.executebuiltin('RunScript("special://skin/xml/py/uicolor_set1.py")')
                elif out_string == "2":
                    xbmc.executebuiltin('RunScript("special://skin/xml/py/uicolor_set2.py")')

