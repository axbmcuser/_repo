# -*- coding: utf-8 -*-

import xbmc
import xbmcvfs
import xbmcgui
import sys
import os
import shutil

try:
    are_you_sure = xbmcgui.Dialog().yesno("Confluence ZEITGEIST",'[COLOR=redwarning]Warning:[/COLOR]  Deleting Kodi "userdata/Thumbnails/" folder.[CR]Kodi will be shut down afterwards. Continue?')
    if are_you_sure :
        
        some_target = "special://home/userdata/Thumbnails/"
        
        if sys.version_info.major == 2:# Python 2
          some_target = xbmc.translatePath(some_target).decode('utf-8')
        else:
          some_target = xbmcvfs.translatePath(some_target)
        
        target_is_present = xbmcvfs.exists(some_target)
        
        if target_is_present:
            
            shutil.rmtree(some_target, ignore_errors=True)
            xbmcvfs.rmdir(some_target, force=True)
            
            xbmc.executebuiltin('Notification(Kodi,"userdata/Thumbnails/" deleted. Exiting Kodi now...,5000,DefaultIconWarning.png)')
            
            ShutdownScreenDisabled = xbmc.getCondVisibility("Skin.HasSetting(ShutdownScreenDisabled)")
            if not ShutdownScreenDisabled:
                xbmc.executebuiltin("SetProperty(ShutdownInProgressText,Exit,home)")
            
            xbmc.sleep(5000)
            
            ElecSystem = xbmc.getCondVisibility("System.HasAddon(service.openelec.settings)") or xbmc.getCondVisibility("System.HasAddon(service.libreelec.settings)")
            if ElecSystem:
                os.system("systemctl restart kodi")
            else:
                xbmc.executebuiltin('Quit')
            
        else:
            xbmc.executebuiltin('Notification(Kodi,"userdata/Thumbnails/" already empty,5000,DefaultIconWarning.png)')
        
except:
    pass