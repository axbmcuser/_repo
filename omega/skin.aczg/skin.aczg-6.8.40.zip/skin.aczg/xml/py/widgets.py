# -*- coding: utf-8 -*-
import xbmc, sys, os, time


widget_string = ""
id_base = ""
slot_no = ""

args = sys.argv
for arg in args:
    if arg != os.path.basename(__file__):
        
        if arg.startswith('widget='):
            widget_string = arg[7:]
        
        if arg.startswith('type='):
            active_widget = arg[5:]
        
        if arg.startswith('id_base='):
            id_base = arg[8:]
        
        if arg.startswith('slot_no='):
            slot_no = arg[8:]
        
        if arg.startswith('cancel'):
            active_widget = arg





if active_widget == "cancel":
    
    reset_position = False
    
    xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Cancel,true,home)')
    
    xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Choose,,home)')
    
    if xbmc.getCondVisibility('!String.IsEmpty(Window(Home).Property(Home_Widget_'+widget_string+'_Active))') and xbmc.getCondVisibility('!String.IsEqual(Window(Home).Property(Home_Widget_'+widget_string+'_Active),Skin.String(Home_Widget_'+widget_string+'_1))'):
        
        xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Changing,true,home)')
        
        time.sleep(0.25)
        
        xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Active,,home)')
        xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Active_Slot_No,,home)')
        
        
        
        
        reset_position = True
    
    
    
    xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Active,,home)')
    xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Active_Slot_No,,home)')
    
    xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Cancel,,home)')
    
    
    
    if xbmc.getCondVisibility('String.IsEmpty(Window(Home).Property(Home_Widget_'+widget_string+'_Active))'):
        reset_position = True
    
    
    if reset_position:
        
        current_item = xbmc.getInfoLabel('Container('+id_base+').CurrentItem')
        test = int(xbmc.getInfoLabel('Container('+id_base+').CurrentItem')) if current_item != "" and current_item else -1
        
        test2 = int(-test+1)
        
        if int(test) > 1:
            
            xbmc.executebuiltin('Control.Move('+id_base+','+str(test2)+')')
    
    
    xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Changing,,home)')






if (
    active_widget != "cancel" 
    and xbmc.getCondVisibility('String.IsEmpty(Window(Home).Property(Home_Widget_'+widget_string+'_Changing))') 
    and (xbmc.getInfoLabel('Window(Home).Property(Home_Widget_'+widget_string+'_Active)') != active_widget or "random" in active_widget) 
    and not (not xbmc.getInfoLabel('Window(Home).Property(Home_Widget_'+widget_string+'_Active)') and xbmc.getInfoLabel('Skin.String(Home_Widget_'+widget_string+'_1)') == active_widget)
    ):
    
    xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Changing,true,home)')
    
    
    if "random" in active_widget:
        xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Force_Change,true,home)')
    
    
    
    
    
    time.sleep(0.25)
    
    if xbmc.getCondVisibility('String.IsEmpty(Window(Home).Property(Home_Widget_'+widget_string+'_Cancel))'):
        
        xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Active,'+active_widget+',home)')
        xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Active_Slot_No,'+slot_no+',home)')
        
    
    
    if "random" in active_widget:
        xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Force_Change,,home)')
    xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Changing,,home)')
    
    
    
    time.sleep(0.1)
    
    current_item = xbmc.getInfoLabel('Container('+id_base+').CurrentItem')
    test = int(xbmc.getInfoLabel('Container('+id_base+').CurrentItem')) if current_item != "" and current_item else -1
    
    test2 = int(-test+1)
    
    if int(test) > 1:
        
        xbmc.executebuiltin('Control.Move('+id_base+','+str(test2)+')')
