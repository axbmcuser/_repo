# -*- coding: utf-8 -*-
import xbmc, xbmcgui, sys, os, time

home_win = xbmcgui.Window(10000)

widget_string = ""
id_base = ""
slot_no = ""

args = sys.argv
for arg in args:
    if arg != os.path.basename(__file__):
        
        if arg.startswith('widget='):
            widget_string = arg[7:]
        
        if arg.startswith('type='):
            active_widget = arg[5:]
        
        if arg.startswith('id_base='):
            id_base = arg[8:]
        
        if arg.startswith('slot_no='):
            slot_no = arg[8:]
        
        if arg.startswith('cancel'):
            active_widget = arg






if active_widget == "cancel":
    
    page_change = False
    
    
    
    home_win.setProperty('Home_Widget_'+widget_string+'_Cancel', 'true')
    home_win.setProperty('Home_Widget_'+widget_string+'_Choose', '')
    
    
    
    widget_page = home_win.getProperty('Home_Widget_Page')
    if widget_page == "2" or widget_page == "3":
        page_change = True
    
    
    
    # change content if needed
    
    if page_change or ( home_win.getProperty('Home_Widget_'+widget_string+'_Active') != '' and home_win.getProperty('Home_Widget_'+widget_string+'_Active') != xbmc.getInfoLabel('Skin.String(Home_Widget_'+widget_string+'_1)') ):
        
        home_win.setProperty('Home_Widget_'+widget_string+'_Changing', 'true')
        
        # wait 250ms for hide animation
        time.sleep(0.25)
        
        # reset active state
        home_win.setProperty('Home_Widget_'+widget_string+'_Active', '')
        home_win.setProperty('Home_Widget_'+widget_string+'_Active_Slot_No', '')
        home_win.setProperty('Home_Widget_Page', '1')
        
        # wait at least 330ms on heavier content changes before executing scroll back
        if page_change:
            time.sleep(0.33)
        
        
    else:
        # reset active state
        home_win.setProperty('Home_Widget_'+widget_string+'_Active', '')
        home_win.setProperty('Home_Widget_'+widget_string+'_Active_Slot_No', '')
        home_win.setProperty('Home_Widget_Page', '1')
    
    
    
    time.sleep(0.1)
    
    while xbmc.getCondVisibility('Container('+id_base+').IsUpdating'):
        time.sleep(0.1)
    
    # scroll back to widget content item 1 in any case
    current_item = xbmc.getInfoLabel('Container('+id_base+').CurrentItem')
    current_item_pos = int(current_item) if current_item != "" and current_item else -1
    if int(current_item_pos) > 1:
        move_item_pos = int(-current_item_pos+1)
        xbmc.executebuiltin('Control.Move('+id_base+','+str(move_item_pos)+')')
    
    
    
    
    
    home_win.setProperty('Home_Widget_'+widget_string+'_Cancel', '')
    home_win.setProperty('Home_Widget_'+widget_string+'_Changing', '')






# change slot
if (
    active_widget != "cancel" 
    and (home_win.getProperty('Home_Widget_'+widget_string+'_Active_Slot_No') != slot_no or "random" in active_widget) 
    and home_win.getProperty('Home_Widget_'+widget_string+'_Choose') != ''
    ):
    
    page_change = False
    
    home_win.setProperty('Home_Widget_'+widget_string+'_Changing', 'true')
    
    
    if "random" in active_widget:
        home_win.setProperty('Home_Widget_'+widget_string+'_Force_Change', 'true')
    
    
    
    widget_page = home_win.getProperty('Home_Widget_Page')
    if widget_page == "2" or widget_page == "3":
        page_change = True
    
    
    
    # wait 250ms for hide animation
    time.sleep(0.25)
    
    
    if home_win.getProperty('Home_Widget_'+widget_string+'_Cancel') == '':
        
        home_win.setProperty('Home_Widget_'+widget_string+'_Active', active_widget)
        home_win.setProperty('Home_Widget_'+widget_string+'_Active_Slot_No', slot_no)
        home_win.setProperty('Home_Widget_Page', '1')
        
        # wait at least 330ms on heavier content changes before executing scroll back
        if page_change:
            time.sleep(0.33)
    
    
    if "random" in active_widget:
        home_win.setProperty('Home_Widget_'+widget_string+'_Force_Change', '')
    
    
    
    
    
    time.sleep(0.1)
    
    
    
    
    # scroll back to widget content item 1 in any case
    
    while xbmc.getCondVisibility('Container('+id_base+').IsUpdating'):
        time.sleep(0.1)
    
    
    current_item = xbmc.getInfoLabel('Container('+id_base+').CurrentItem')
    current_item_pos = int(current_item) if current_item != "" and current_item else -1
    
    is_tmdb_widget = xbmc.getCondVisibility('String.StartsWith(Control.GetLabel('+id_base+'66),plugin://plugin.video.themoviedb.helper)')
    
    if int(current_item_pos) > 1:
        if xbmc.getCondVisibility('ControlGroup('+id_base+'0).HasFocus'):
            xbmc.executebuiltin('SetFocus('+id_base+',0,absolute)')
            xbmc.executebuiltin('SetFocus('+id_base+'0)')
        
        if is_tmdb_widget:
            time.sleep(0.25)
        
    elif is_tmdb_widget:
        time.sleep(0.22)
    
    
    home_win.setProperty('Home_Widget_'+widget_string+'_Changing', '')















# reveal all slots

if (
    active_widget != "cancel" 
    and home_win.getProperty('Home_Widget_'+widget_string+'_Choose') == ''
    ):
    home_win.setProperty('Home_Widget_'+widget_string+'_Choose', 'true')
    home_win.setProperty('Home_Widget_'+widget_string+'_Active_Slot_No', slot_no)
    home_win.setProperty('Home_Widget_Page', '1')



