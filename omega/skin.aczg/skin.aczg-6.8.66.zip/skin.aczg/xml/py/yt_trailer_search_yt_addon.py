# -*- coding: utf-8 -*-

import xbmc, sys
import urllib.parse

try:
    language_string = ' '+sys.argv[3] if sys.argv[3] else ''
    year_string     = ' '+sys.argv[2] if sys.argv[2] else ''
    
    search_string = sys.argv[1] + ' Trailer' + language_string + year_string
    
    search_string = urllib.parse.quote_plus(search_string)
    
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.video.youtube/kodion/search/query/?q='+search_string+'",return)')
    
except:
    pass
