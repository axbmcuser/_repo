# -*- coding: utf-8 -*-

import xbmc, xbmcgui, time

try:
    
    home_win = xbmcgui.Window(10000)
    
    if home_win.getProperty('NewVersionInfoTimeout_Stopped'):
        home_win.clearProperty('NewVersionInfoTimeout_Stopped')
    
    if not home_win.getProperty('NewVersionInfoTimeout_Stopped'):
        home_win.setProperty('NewVersionInfoTimeout','10')
        home_win.setProperty('NewVersionInfoTimeout_Label',' (10s)')
        time.sleep(1)
    if not home_win.getProperty('NewVersionInfoTimeout_Stopped'):
        home_win.setProperty('NewVersionInfoTimeout','9')
        home_win.setProperty('NewVersionInfoTimeout_Label',' (9s)')
        time.sleep(1)
    if not home_win.getProperty('NewVersionInfoTimeout_Stopped'):
        home_win.setProperty('NewVersionInfoTimeout','8')
        home_win.setProperty('NewVersionInfoTimeout_Label',' (8s)')
        time.sleep(1)
    if not home_win.getProperty('NewVersionInfoTimeout_Stopped'):
        home_win.setProperty('NewVersionInfoTimeout','7')
        home_win.setProperty('NewVersionInfoTimeout_Label',' (7s)')
        time.sleep(1)
    if not home_win.getProperty('NewVersionInfoTimeout_Stopped'):
        home_win.setProperty('NewVersionInfoTimeout','6')
        home_win.setProperty('NewVersionInfoTimeout_Label',' (6s)')
        time.sleep(1)
    if not home_win.getProperty('NewVersionInfoTimeout_Stopped'):
        home_win.setProperty('NewVersionInfoTimeout','5')
        home_win.setProperty('NewVersionInfoTimeout_Label',' (5s)')
        time.sleep(1)
    if not home_win.getProperty('NewVersionInfoTimeout_Stopped'):
        home_win.setProperty('NewVersionInfoTimeout','4')
        home_win.setProperty('NewVersionInfoTimeout_Label',' (4s)')
        time.sleep(1)
    if not home_win.getProperty('NewVersionInfoTimeout_Stopped'):
        home_win.setProperty('NewVersionInfoTimeout','3')
        home_win.setProperty('NewVersionInfoTimeout_Label',' (3s)')
        time.sleep(1)
    if not home_win.getProperty('NewVersionInfoTimeout_Stopped'):
        home_win.setProperty('NewVersionInfoTimeout','2')
        home_win.setProperty('NewVersionInfoTimeout_Label',' (2s)')
        time.sleep(1)
    if not home_win.getProperty('NewVersionInfoTimeout_Stopped'):
        home_win.setProperty('NewVersionInfoTimeout','1')
        home_win.setProperty('NewVersionInfoTimeout_Label',' (1s)')
        time.sleep(1)
    if not home_win.getProperty('NewVersionInfoTimeout_Stopped'):
        home_win.setProperty('NewVersionInfoTimeout','0')
        home_win.setProperty('NewVersionInfoTimeout_Label',' (0s)')
        time.sleep(0.5)
    
    if not home_win.getProperty('NewVersionInfoTimeout_Stopped'):
        xbmc.executebuiltin('Dialog.Close(YesNoDialog)')
    
except:
    pass