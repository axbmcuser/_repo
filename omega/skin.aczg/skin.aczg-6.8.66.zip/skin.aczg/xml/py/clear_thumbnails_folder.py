# -*- coding: utf-8 -*-

import xbmc, xbmcgui, sys, os, xbmcvfs, shutil

home_win = xbmcgui.Window(10000)

try:
    are_you_sure = xbmcgui.Dialog().yesno("Confluence ZEITGEIST",'[COLOR=redwarning]Warning:[/COLOR]  Deleting Kodi "userdata/Thumbnails/" folder.[CR]Kodi will be shut down afterwards. Continue?')
    if are_you_sure:
        
        some_target = "special://home/userdata/Thumbnails"
        some_target_s = some_target + '/'
        
        some_target = xbmcvfs.translatePath(some_target)
        some_target_s = xbmcvfs.translatePath(some_target_s)
        
        target_is_present = xbmcvfs.exists(some_target_s)
        
        if target_is_present:
            
            shutil.rmtree(some_target_s, ignore_errors=True)
            xbmcvfs.rmdir(some_target_s, force=True)
            
            xbmc.executebuiltin('Notification(Kodi,"userdata/Thumbnails/" deleted. Exiting Kodi now...,5000,DefaultIconWarning.png)')
            
            ShutdownScreenDisabled = xbmc.getCondVisibility("Skin.HasSetting(ShutdownScreenDisabled)")
            if not ShutdownScreenDisabled:
                home_win.setProperty('CZ.ShutdownScreenActiveText', 'Delete Thumbnails Folder')
            
            xbmc.sleep(5000)
            
            ElecSystem = xbmc.getCondVisibility("System.HasAddon(service.libreelec.settings) | System.HasAddon(service.coreelec.settings)")
            
            if ElecSystem:
                os.system("systemctl restart kodi")
            else:
                xbmc.executebuiltin('Quit')
            
        else:
            xbmc.executebuiltin('Notification(Kodi,"userdata/Thumbnails/" already empty,5000,DefaultIconWarning.png)')
        
except:
    pass