# -*- coding: utf-8 -*-

import xbmc
import xbmcgui

try:
    show_changelog = xbmcgui.Dialog().yesno("Confluence ZEITGEIST updated","","$LOCALIZE[15067][LIGHT]$INFO[Window(Home).Property(NewVersionInfoTimeout_Label)][/LIGHT]","Changelog")
    if show_changelog:
        xbmc.executebuiltin('ActivateWindow(1186)')
except:
    pass