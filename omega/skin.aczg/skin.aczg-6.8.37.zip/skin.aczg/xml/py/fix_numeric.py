# -*- coding: utf-8 -*-

import xbmc, xbmcgui

# Fixes Kodi Numeric IP bug where entering an IP in IP-mode once causes leftovers for other future numeric dialogs

def fix_numeric():
    win = xbmcgui.Window(10109)
    con = win.getControl(4)
    label = con.getLabel()
    con.setLabel(con.getLabel())

try:
    fix_numeric()
    xbmc.sleep(50)
    fix_numeric()
except:
    pass