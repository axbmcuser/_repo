# -*- coding: utf-8 -*-
import xbmc, sys, os, time


widget_string = ""
id_base = ""
slot_no = ""

args = sys.argv
for arg in args:
    if arg != os.path.basename(__file__):
        
        if arg.startswith('widget='):
            widget_string = arg[7:]
        
        if arg.startswith('type='):
            active_widget = arg[5:]
        
        if arg.startswith('id_base='):
            id_base = arg[8:]
        
        if arg.startswith('slot_no='):
            slot_no = arg[8:]
        
        if arg.startswith('cancel'):
            active_widget = arg








def scroll_back_needed(id_base):
    current_item = xbmc.getInfoLabel('Container('+id_base+').CurrentItem')
    current_item_pos = int(current_item) if current_item != "" and current_item else -1
    return int(current_item_pos) > 1



def scroll_back_now(id_base):
    # scroll back to widget content item 1 in any case
    
    while xbmc.getCondVisibility('Container('+str(id_base)+').IsUpdating'):
        time.sleep(0.1)
    
    if scroll_back_needed(id_base):
        current_item = xbmc.getInfoLabel('Container('+id_base+').CurrentItem')
        current_item_pos = int(current_item) if current_item != "" and current_item else -1
        move_item_pos = int(-current_item_pos+1)
        xbmc.executebuiltin('Control.Move('+id_base+','+str(move_item_pos)+')')







if active_widget == "cancel":
    
    page_change = False
    scroll_back = False
    
    
    
    xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Cancel,true,home)')
    xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Choose,,home)')
    
    
    
    scroll_back = scroll_back_needed(id_base)
    
    
    
    widget_page = xbmc.getInfoLabel('Window(Home).Property(Home_Widget_Page)')
    if widget_page == "2" or widget_page == "3":
        page_change = True
    
    
    
    # change content if needed
    
    if page_change or ( xbmc.getCondVisibility('!String.IsEmpty(Window(Home).Property(Home_Widget_'+widget_string+'_Active))') and xbmc.getCondVisibility('!String.IsEqual(Window(Home).Property(Home_Widget_'+widget_string+'_Active),Skin.String(Home_Widget_'+widget_string+'_1))') ):
        
        xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Changing,true,home)')
        
        # wait 250ms for hide animation
        time.sleep(0.25)
        
        # reset active state
        xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Active,,home)')
        xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Active_Slot_No,,home)')
        xbmc.executebuiltin('SetProperty(Home_Widget_Page,1,home)')
        
        # wait at least 300ms on heavier content changes before executing scroll back
        if page_change:
            time.sleep(0.33)
        
        
    else:
        # reset active state
        xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Active,,home)')
        xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Active_Slot_No,,home)')
        xbmc.executebuiltin('SetProperty(Home_Widget_Page,1,home)')
    
    
    
    
    if scroll_back:
        # scroll back to widget content item 1 in any case
        scroll_back_now(id_base)
    
    
    
    xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Cancel,,home)')
    xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Changing,,home)')






# change slot
if (
    active_widget != "cancel" 
    and (xbmc.getInfoLabel('Window(Home).Property(Home_Widget_'+widget_string+'_Active_Slot_No)') != slot_no or "random" in active_widget) 
    and xbmc.getCondVisibility('!String.IsEmpty(Window(Home).Property(Home_Widget_'+widget_string+'_Choose))')
    ):
    
    page_change = False
    scroll_back = False
    
    xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Changing,true,home)')
    
    
    if "random" in active_widget:
        xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Force_Change,true,home)')
    
    
    
    scroll_back = scroll_back_needed(id_base)
    
    
    
    widget_page = xbmc.getInfoLabel('Window(Home).Property(Home_Widget_Page)')
    if widget_page == "2" or widget_page == "3":
        page_change = True
    
    
    
    # wait 250ms for hide animation
    time.sleep(0.25)
    
    
    if xbmc.getCondVisibility('String.IsEmpty(Window(Home).Property(Home_Widget_'+widget_string+'_Cancel))'):
        
        xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Active,'+active_widget+',home)')
        xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Active_Slot_No,'+slot_no+',home)')
        xbmc.executebuiltin('SetProperty(Home_Widget_Page,1,home)')
        
        # wait at least 300ms on heavier content changes before executing scroll back
        if page_change:
            time.sleep(0.33)
    
    
    if "random" in active_widget:
        xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Force_Change,,home)')
    
    xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Changing,,home)')
    
    
    
    time.sleep(0.1)
    
    
    
    if scroll_back:
        # scroll back to widget content item 1 in any case
        scroll_back_now(id_base)






# reveal all slots

if (
    active_widget != "cancel" 
    and xbmc.getCondVisibility('String.IsEmpty(Window(Home).Property(Home_Widget_'+widget_string+'_Choose))')
    ):
    xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Choose,true,home)')
    xbmc.executebuiltin('SetProperty(Home_Widget_'+widget_string+'_Active_Slot_No,'+slot_no+',home)')
    xbmc.executebuiltin('SetProperty(Home_Widget_Page,1,home)')



